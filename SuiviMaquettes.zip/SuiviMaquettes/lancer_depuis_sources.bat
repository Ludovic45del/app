@echo off
rem Lance l'application directement depuis le code (sans compiler) : pratique pour tester.
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
call "%~dp0outils\trouver_python.bat" || ( pause & exit /b 1 )
%PY% src\main.py
if errorlevel 1 pause
