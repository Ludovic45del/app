@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Suivi des maquettes - Etape 2 : compilation
echo.
echo  ================================================================
echo   ETAPE 2 / 2  -  Fabrication de l'application (sans internet)
echo  ================================================================
echo.
call "%~dp0outils\trouver_python.bat" || goto :erreur

if not exist "wheels\*.whl" (
    echo.
    echo  [ERREUR] Le dossier "wheels" est vide : lancez d'abord 1_PREPARER_HORS_LIGNE.bat
    goto :erreur
)

if not exist ".venv-build\Scripts\python.exe" (
    echo.
    echo  [1/4] Creation de l'environnement de compilation...
    %PY% -m venv .venv-build || goto :erreur
) else (
    echo.
    echo  [1/4] Environnement de compilation deja present.
)
set "VPY=%~dp0.venv-build\Scripts\python.exe"

echo  [2/4] Installation de PyInstaller depuis le dossier "wheels" (hors ligne)...
"%VPY%" -m pip install --disable-pip-version-check --quiet --no-index --find-links wheels -r outils\requirements-build.txt
if errorlevel 1 goto :erreur

echo  [3/4] Tests automatiques de l'application...
"%VPY%" tests\test_donnees.py 2>"%TEMP%\suivi_tests.log"
if errorlevel 1 (
    type "%TEMP%\suivi_tests.log"
    echo  [ERREUR] Des tests ont echoue : compilation annulee.
    goto :erreur
)
echo        Tous les tests sont passes.

echo  [4/4] Compilation (1 a 3 minutes)...
"%VPY%" outils\construire.py
if errorlevel 1 goto :erreur

echo.
echo  ----------------------------------------------------------------
echo   TERMINE. Tout est dans le dossier "livraison" :
echo     - SuiviMaquettes\        version dossier (recommandee)
echo     - SuiviMaquettes.exe     version fichier unique
echo  ----------------------------------------------------------------
echo.
start "" explorer "%~dp0livraison"
pause
exit /b 0

:erreur
echo.
echo  ECHEC. Lisez le message ci-dessus et la section "Depannage" du README.
echo.
pause
exit /b 1
