@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Suivi des maquettes - Plan B : version portable
echo.
echo  ================================================================
echo   PLAN B (antivirus)  -  Version portable sans exe compile
echo   A utiliser seulement si l'antivirus bloque SuiviMaquettes.exe
echo  ================================================================
echo.
call "%~dp0outils\trouver_python.bat" || goto :erreur
%PY% outils\construire.py --portable
if errorlevel 1 goto :erreur
echo.
start "" explorer "%~dp0livraison"
pause
exit /b 0

:erreur
echo.
echo  ECHEC. Lisez le message ci-dessus et la section "Depannage" du README.
echo.
pause
exit /b 1
