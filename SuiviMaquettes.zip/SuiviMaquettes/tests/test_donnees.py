"""Tests de la couche données. Lancer :  python -m unittest discover -s tests"""

import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from suivi_maquettes.db import Base, ErreurMetier, Trace  # noqa: E402
from suivi_maquettes.export import exporter_tout  # noqa: E402
from suivi_maquettes.formats import (ErreurSaisie, format_duree, parse_date,  # noqa: E402
                                     parse_duree)
from suivi_maquettes.verrou import Verrou  # noqa: E402

P = [f"v{i}" for i in range(1, 10)]


def trace(**kw):
    base = dict(auteur="Alice", date_effet="2026-10-26", type="Évolution",
                demandeur="Bob", objet="Test")
    base.update(kw)
    return Trace(**base)


class TestFormats(unittest.TestCase):
    def test_durees(self):
        for saisie, attendu in [("1h30", 90), ("1:30", 90), ("1 h 05", 65), ("2h", 120),
                                ("1,5", 90), ("1.25", 75), ("12", 720), ("45 min", 45),
                                ("90m", 90)]:
            self.assertEqual(parse_duree(saisie), attendu, saisie)
        for mauvais in ["", "abc", "1h75", "0", "-2"]:
            with self.assertRaises(ErreurSaisie, msg=mauvais):
                parse_duree(mauvais)
        self.assertEqual(format_duree(1234), "20 h 34")
        self.assertEqual(format_duree(-70), "−1 h 10")

    def test_dates(self):
        self.assertEqual(parse_date("26/10/2026"), "2026-10-26")
        self.assertEqual(parse_date("1.2.26"), "2026-02-01")
        self.assertEqual(parse_date("2026-10-26"), "2026-10-26")
        for mauvais in ["31/02/2026", "hier", ""]:
            with self.assertRaises(ErreurSaisie):
                parse_date(mauvais)


class TestBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Base(Path(self.tmp.name))

    def tearDown(self):
        self.base.fermer()
        self.tmp.cleanup()

    def test_cycle_complet(self):
        mid = self.base.creer_maquette("SN-001", 50 * 60, P, trace(type="Initiale"))
        with self.assertRaises(ErreurMetier):
            self.base.creer_maquette("sn-001", 60, P, trace())     # doublon insensible à la casse

        with self.assertRaises(ErreurMetier):
            self.base.nouvelle_configuration(mid, P, trace())       # rien de modifié
        with self.assertRaises(ErreurMetier):
            self.base.nouvelle_configuration(mid, ["x", *P[1:]], trace(demandeur=" "))
        v = self.base.nouvelle_configuration(mid, ["x", *P[1:]], trace())
        self.assertEqual(v, 2)

        self.base.ajouter_vol(mid, "2026-10-20", 90, "Équipe A", "RAS")
        vid = self.base.ajouter_vol(mid, "2026-10-21", 30, "Équipe B")
        m = self.base.maquette(mid)
        self.assertEqual((m.consomme, m.restant, m.version, m.nb_vols), (120, 2880, 2, 2))
        self.assertEqual(m.parametres[0], "x")

        hist = self.base.configurations(mid)
        self.assertEqual([c.version for c in hist], [2, 1])

        self.base.supprimer_vol(vid)
        self.assertEqual(self.base.maquette(mid).consomme, 90)
        self.assertTrue(list(self.base.dossier_sauvegardes.glob("*.db")))

        fichiers = exporter_tout(self.base, Path(self.tmp.name))
        self.assertTrue(all(f.stat().st_size > 0 for f in fichiers))

        self.base.supprimer_maquette(mid)
        self.assertEqual(self.base.liste_maquettes(), [])
        self.assertEqual(self.base.cx.execute("SELECT COUNT(*) FROM vol").fetchone()[0], 0)

    def test_reglages_et_lecture_seule(self):
        self.base.definir_reglages({"nom_p1": "Moteur"})
        self.assertEqual(self.base.noms_parametres()[:2], ["Moteur", "Paramètre 2"])
        ro = Base(Path(self.tmp.name), lecture_seule=True)
        with self.assertRaises(ErreurMetier):
            ro.ajouter_vol(1, "2026-10-26", 10, "X")
        ro.fermer()

    def test_performance(self):
        t = time.perf_counter()
        for i in range(60):
            mid = self.base.creer_maquette(f"SN-{i:04d}", 3000, P, trace())
            for j in range(5):
                self.base.ajouter_vol(mid, "2026-01-01", 10, "E")
        t = time.perf_counter()
        self.assertEqual(len(self.base.liste_maquettes()), 60)
        self.assertLess(time.perf_counter() - t, 0.2)


class TestVerrou(unittest.TestCase):
    def test_exclusion_et_prise_de_main(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Verrou(Path(d)), Verrou(Path(d))
            self.assertIsNone(a.acquerir())
            autre = b.acquerir()
            self.assertIsNotNone(autre)
            self.assertFalse(autre.perime)
            self.assertIsNone(b.acquerir(forcer=True))
            self.assertFalse(a.est_a_nous())
            self.assertTrue(a.perdu)
            a.liberer()                                  # ne doit pas supprimer le verrou de b
            self.assertTrue(b.est_a_nous())
            b.liberer()
            self.assertIsNone(b.lire())


if __name__ == "__main__":
    unittest.main()
