"""Point d'entrée de Suivi des maquettes (utilisé par PyInstaller et par lancer_sources.bat)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from suivi_maquettes.demarrage import lancer  # noqa: E402

if __name__ == "__main__":
    sys.exit(lancer())
