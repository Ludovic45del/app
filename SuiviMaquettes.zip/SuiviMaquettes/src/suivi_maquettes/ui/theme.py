"""Thème visuel : palette, polices, styles ttk (base « clam », entièrement redessinée)."""

from __future__ import annotations

import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk


class Palette:
    FOND = "#F3F5F8"
    SURFACE = "#FFFFFF"
    SURFACE_2 = "#F7F9FB"
    BORDURE = "#DFE3EA"
    BORDURE_FORTE = "#C8CFDA"
    TEXTE = "#1A2332"
    TEXTE_2 = "#5B6575"
    TEXTE_3 = "#8A93A3"

    ACCENT = "#1F5BB4"
    ACCENT_SURVOL = "#194C97"
    ACCENT_DOUX = "#E9F0FB"
    ACCENT_CHAMP = "#F4F8FE"
    SELECTION = "#DDE8F8"

    ENTETE = "#13213B"
    ENTETE_2 = "#22335A"
    ENTETE_TEXTE = "#FFFFFF"
    ENTETE_TEXTE_2 = "#A9B6CF"

    OK = "#1E8A50"
    OK_DOUX = "#E6F4EC"
    ALERTE = "#C27400"
    ALERTE_DOUX = "#FCF1E1"
    DANGER = "#C4352D"
    DANGER_SURVOL = "#A72B24"
    DANGER_DOUX = "#FBEAE8"

    PISTE = "#E6EAF0"


P = Palette


class Theme:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.echelle = max(1.0, root.winfo_fpixels("1i") / 96.0)
        self._polices()
        self._styles()

    def px(self, valeur: float) -> int:
        return int(round(valeur * self.echelle))

    # ------------------------------------------------------------------ polices
    def _polices(self) -> None:
        familles = set(tkfont.families(self.root))
        corps = next((f for f in ("Segoe UI", "Inter", "Noto Sans", "DejaVu Sans") if f in familles),
                     "TkDefaultFont")
        semi = "Segoe UI Semibold" if "Segoe UI Semibold" in familles else corps
        poids_semi = "normal" if semi != corps else "bold"

        def police(nom, famille, taille, poids="normal"):
            return tkfont.Font(self.root, name=nom, family=famille, size=taille, weight=poids)

        self.f_corps = police("Corps", corps, 10)
        self.f_corps_semi = police("CorpsSemi", semi, 10, poids_semi)
        self.f_petit = police("Petit", corps, 9)
        self.f_petit_semi = police("PetitSemi", semi, 9, poids_semi)
        self.f_titre = police("Titre", semi, 17, poids_semi)
        self.f_sous_titre = police("SousTitre", semi, 12, poids_semi)
        self.f_entete = police("Entete", semi, 13, poids_semi)
        self.f_chiffre = police("Chiffre", semi, 18, poids_semi)

        for nom in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            try:
                tkfont.nametofont(nom).configure(family=corps, size=10)
            except tk.TclError:
                pass

    # ------------------------------------------------------------------ styles
    def _styles(self) -> None:
        s = ttk.Style(self.root)
        s.theme_use("clam")
        px = self.px
        self.root.configure(background=P.FOND)
        self.root.option_add("*TCombobox*Listbox.font", self.f_corps)

        s.configure(".", background=P.FOND, foreground=P.TEXTE, font=self.f_corps,
                    bordercolor=P.BORDURE, lightcolor=P.FOND, darkcolor=P.FOND,
                    troughcolor=P.FOND, focuscolor=P.ACCENT, selectbackground=P.SELECTION,
                    selectforeground=P.TEXTE, insertcolor=P.TEXTE)

        # Cadres
        s.configure("TFrame", background=P.FOND)
        s.configure("Surface.TFrame", background=P.SURFACE)
        s.configure("Surface2.TFrame", background=P.SURFACE_2)
        s.configure("Carte.TFrame", background=P.SURFACE, relief="solid", borderwidth=1,
                    bordercolor=P.BORDURE, lightcolor=P.BORDURE, darkcolor=P.BORDURE)
        s.configure("Tuile.TFrame", background=P.SURFACE_2, relief="solid", borderwidth=1,
                    bordercolor=P.BORDURE, lightcolor=P.BORDURE, darkcolor=P.BORDURE)
        s.configure("Entete.TFrame", background=P.ENTETE)
        s.configure("Separateur.TFrame", background=P.BORDURE)
        s.configure("Accent.TFrame", background=P.ACCENT)
        for nom, fond, texte in (("Danger", P.DANGER_DOUX, P.DANGER), ("Alerte", P.ALERTE_DOUX, P.ALERTE),
                                 ("Info", P.ACCENT_DOUX, P.ACCENT)):
            s.configure(f"Bandeau{nom}.TFrame", background=fond)
            s.configure(f"Bandeau{nom}.TLabel", background=fond, foreground=texte)
            s.configure(f"Bandeau{nom}Semi.TLabel", background=fond, foreground=texte,
                        font=self.f_corps_semi)

        # Libellés
        for nom, fond in (("", P.FOND), ("Surface.", P.SURFACE), ("Surface2.", P.SURFACE_2)):
            s.configure(f"{nom}TLabel", background=fond, foreground=P.TEXTE)
            s.configure(f"{nom}Gris.TLabel", background=fond, foreground=P.TEXTE_2)
            s.configure(f"{nom}Pale.TLabel", background=fond, foreground=P.TEXTE_3, font=self.f_petit)
            s.configure(f"{nom}Semi.TLabel", background=fond, foreground=P.TEXTE, font=self.f_corps_semi)
            s.configure(f"{nom}Titre.TLabel", background=fond, foreground=P.TEXTE, font=self.f_titre)
            s.configure(f"{nom}SousTitre.TLabel", background=fond, foreground=P.TEXTE,
                        font=self.f_sous_titre)
            s.configure(f"{nom}Libelle.TLabel", background=fond, foreground=P.TEXTE_2,
                        font=self.f_petit_semi)
            s.configure(f"{nom}Chiffre.TLabel", background=fond, foreground=P.TEXTE, font=self.f_chiffre)
            s.configure(f"{nom}Erreur.TLabel", background=fond, foreground=P.DANGER)
            s.configure(f"{nom}Modifie.TLabel", background=fond, foreground=P.ACCENT,
                        font=self.f_petit_semi)
        s.configure("EnteteTitre.TLabel", background=P.ENTETE, foreground=P.ENTETE_TEXTE,
                    font=self.f_entete)
        s.configure("EnteteSous.TLabel", background=P.ENTETE, foreground=P.ENTETE_TEXTE_2,
                    font=self.f_petit)
        for nom, fg, bg in (("BadgeOk", P.OK, P.OK_DOUX), ("BadgeAlerte", P.ALERTE, P.ALERTE_DOUX),
                            ("BadgeDanger", P.DANGER, P.DANGER_DOUX),
                            ("BadgeAccent", P.ACCENT, P.ACCENT_DOUX)):
            s.configure(f"{nom}.TLabel", background=bg, foreground=fg, font=self.f_petit_semi,
                        padding=(px(8), px(2)))
        s.configure("BadgeEntete.TLabel", background="#F4B740", foreground="#2B1D00",
                    font=self.f_petit_semi, padding=(px(10), px(3)))

        # Boutons
        pad = (px(14), px(6))
        self._bouton(s, "TButton", "#ECEFF4", P.TEXTE, "#ECEFF4", "#DFE4EC", pad,
                     desactive_bg="#F3F5F8", desactive_fg=P.TEXTE_3)
        self._bouton(s, "Accent.TButton", P.ACCENT, "#FFFFFF", P.ACCENT, P.ACCENT_SURVOL, pad,
                     desactive_bg="#A8BEDF", police=self.f_corps_semi)
        self._bouton(s, "Danger.TButton", P.DANGER, "#FFFFFF", P.DANGER, P.DANGER_SURVOL, pad,
                     desactive_bg="#E6B1AD", police=self.f_corps_semi)
        self._bouton(s, "DangerLeger.TButton", P.DANGER_DOUX, P.DANGER, P.DANGER_DOUX, "#F5D6D3",
                     pad, desactive_bg="#FBF3F2", desactive_fg="#DDB0AC")
        self._bouton(s, "Entete.TButton", P.ENTETE, P.ENTETE_TEXTE, P.ENTETE_2, P.ENTETE_2,
                     (px(12), px(5)), desactive_bg=P.ENTETE, desactive_fg="#5E6C88")
        self._bouton(s, "Lien.TButton", P.SURFACE, P.ACCENT, P.SURFACE, P.ACCENT_DOUX,
                     (px(6), px(3)))

        # Onglets maison
        s.configure("Onglet.TLabel", background=P.SURFACE, foreground=P.TEXTE_2,
                    font=self.f_corps_semi, padding=(px(2), px(8)))
        s.configure("OngletActif.TLabel", background=P.SURFACE, foreground=P.ACCENT,
                    font=self.f_corps_semi, padding=(px(2), px(8)))

        # Champs de saisie
        champ = dict(fieldbackground=P.SURFACE, foreground=P.TEXTE, bordercolor=P.BORDURE_FORTE,
                     lightcolor=P.SURFACE, darkcolor=P.SURFACE, padding=(px(8), px(5)),
                     insertcolor=P.TEXTE, selectbackground=P.SELECTION, selectforeground=P.TEXTE)
        s.configure("TEntry", **champ)
        s.map("TEntry",
              bordercolor=[("focus", P.ACCENT)],
              lightcolor=[("focus", P.ACCENT_DOUX)],
              fieldbackground=[("readonly", P.SURFACE_2), ("disabled", P.SURFACE_2)],
              foreground=[("disabled", P.TEXTE_3)])
        s.configure("Erreur.TEntry", **{**champ, "bordercolor": P.DANGER, "lightcolor": P.DANGER_DOUX})
        s.map("Erreur.TEntry", bordercolor=[("focus", P.DANGER)])
        s.configure("Modifie.TEntry", **{**champ, "bordercolor": P.ACCENT,
                                         "fieldbackground": P.ACCENT_CHAMP})
        s.map("Modifie.TEntry", bordercolor=[("focus", P.ACCENT)])
        s.configure("Recherche.TEntry", **{**champ, "padding": (px(10), px(6))})
        s.map("Recherche.TEntry", bordercolor=[("focus", P.ACCENT)],
              lightcolor=[("focus", P.ACCENT_DOUX)])

        s.configure("TCheckbutton", background=P.SURFACE, foreground=P.TEXTE,
                    indicatorbackground=P.SURFACE, indicatorforeground=P.ACCENT)

        # Tableaux
        s.layout("Tableau.Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
        s.configure("Tableau.Treeview", background=P.SURFACE, fieldbackground=P.SURFACE,
                    foreground=P.TEXTE, rowheight=px(32), borderwidth=0, font=self.f_corps)
        s.map("Tableau.Treeview",
              background=[("selected", P.SELECTION)],
              foreground=[("selected", P.TEXTE)])
        s.configure("Tableau.Treeview.Heading", background=P.SURFACE_2, foreground=P.TEXTE_2,
                    font=self.f_petit_semi, relief="flat", borderwidth=1, bordercolor=P.BORDURE,
                    lightcolor=P.SURFACE_2, darkcolor=P.BORDURE, padding=(px(8), px(6)))
        s.map("Tableau.Treeview.Heading", background=[("active", "#EDF0F5")])

        # Barres de défilement fines
        for orient in ("Vertical", "Horizontal"):
            nom = f"Fin.{orient}.TScrollbar"
            s.layout(nom, [(f"{orient}.Scrollbar.trough", {"sticky": "nswe", "children": [
                (f"{orient}.Scrollbar.thumb", {"expand": "1", "sticky": "nswe"})]})])
            s.configure(nom, troughcolor=P.SURFACE, background="#CBD2DC", bordercolor=P.SURFACE,
                        lightcolor="#CBD2DC", darkcolor="#CBD2DC", gripcount=0,
                        arrowsize=px(9), width=px(9))
            s.map(nom, background=[("active", "#A9B2C0")], lightcolor=[("active", "#A9B2C0")],
                  darkcolor=[("active", "#A9B2C0")])

        s.configure("TPanedwindow", background=P.FOND)
        s.configure("Sash", sashthickness=px(14), background=P.FOND, lightcolor=P.FOND,
                    bordercolor=P.FOND, gripcount=0)

    def _bouton(self, s: ttk.Style, nom: str, bg: str, fg: str, bord: str, survol: str, pad,
                desactive_bg: str | None = None, desactive_fg: str | None = None, police=None):
        s.configure(nom, background=bg, foreground=fg, bordercolor=bord, lightcolor=bg,
                    darkcolor=bg, focuscolor=bg, padding=pad, relief="flat", borderwidth=1,
                    font=police or self.f_corps, anchor="center", focusthickness=0)
        s.map(nom,
              background=[("disabled", desactive_bg or bg), ("pressed", survol), ("active", survol)],
              lightcolor=[("disabled", desactive_bg or bg), ("pressed", survol), ("active", survol)],
              darkcolor=[("disabled", desactive_bg or bg), ("pressed", survol), ("active", survol)],
              foreground=[("disabled", desactive_fg or ("#FFFFFF" if desactive_bg else P.TEXTE_3))],
              bordercolor=[("focus", P.ACCENT if not nom.startswith("Entete") else bord)])
