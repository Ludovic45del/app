"""Composants d'interface réutilisables."""

from __future__ import annotations

import base64
import math
import struct
import tkinter as tk
import zlib
from tkinter import ttk
from typing import Any, Callable

from .theme import P, Theme

# ---------------------------------------------------------------------------- images
# Images générées à la volée en PNG avec transparence : rendu lissé (anticrénelé)
# net à toutes les échelles d'affichage, sans aucune dépendance externe.


def _hex(c: str) -> tuple[int, int, int]:
    return int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)


def _png(largeur: int, hauteur: int, pixels: bytearray) -> str:
    ligne = largeur * 4
    brut = b"".join(b"\x00" + bytes(pixels[y * ligne:(y + 1) * ligne]) for y in range(hauteur))

    def bloc(t: bytes, d: bytes) -> bytes:
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    png = (b"\x89PNG\r\n\x1a\n"
           + bloc(b"IHDR", struct.pack(">IIBBBBB", largeur, hauteur, 8, 6, 0, 0, 0))
           + bloc(b"IDAT", zlib.compress(brut, 6)) + bloc(b"IEND", b""))
    return base64.b64encode(png).decode("ascii")


def pastille(couleur: str, taille: int) -> tk.PhotoImage:
    r, g, b = _hex(couleur)
    px = bytearray(taille * taille * 4)
    rayon = taille * 0.36
    c = taille / 2
    for y in range(taille):
        for x in range(taille):
            d = math.hypot(x + 0.5 - c, y + 0.5 - c)
            a = max(0.0, min(1.0, rayon - d + 0.5))
            i = (y * taille + x) * 4
            px[i:i + 4] = bytes((r, g, b, int(a * 255)))
    return tk.PhotoImage(data=_png(taille, taille, px))


def barre_capsule(largeur: int, hauteur: int, ratio: float, couleur: str) -> tk.PhotoImage:
    """Barre de progression arrondie : piste grise + remplissage coloré."""
    largeur, hauteur = max(hauteur * 2, largeur), max(2, hauteur)
    rp, gp, bp = _hex(P.PISTE)
    rc, gc, bc = _hex(couleur)
    r = hauteur / 2
    cy = hauteur / 2
    fin = 0.0 if ratio <= 0 else max(hauteur, min(1.0, ratio) * largeur)
    px = bytearray(largeur * hauteur * 4)

    def couverture(x: float, y: float, x0: float, x1: float) -> float:
        cx = min(max(x, x0 + r), x1 - r)
        return max(0.0, min(1.0, r - math.hypot(x - cx, y - cy) + 0.5))

    for y in range(hauteur):
        yc = y + 0.5
        for x in range(largeur):
            xc = x + 0.5
            ap = couverture(xc, yc, 0, largeur)
            if ap <= 0:
                continue
            af = couverture(xc, yc, 0, fin) if fin else 0.0
            i = (y * largeur + x) * 4
            px[i] = int(rp + (rc - rp) * af)
            px[i + 1] = int(gp + (gc - gp) * af)
            px[i + 2] = int(bp + (bc - bp) * af)
            px[i + 3] = int(ap * 255)
    return tk.PhotoImage(data=_png(largeur, hauteur, px))


def couleur_etat(restant: int, alloue: int, seuil: int) -> str:
    if restant <= 0:
        return P.DANGER
    if alloue > 0 and restant * 100 < alloue * seuil:
        return P.ALERTE
    return P.OK


class BarrePotentiel(ttk.Label):
    """Barre arrondie qui se redessine à la largeur disponible."""

    def __init__(self, parent, theme: Theme, hauteur: int = 10, **kw):
        super().__init__(parent, style="Surface.TLabel", anchor="w", **kw)
        self.theme = theme
        self.hauteur = theme.px(hauteur)
        self.ratio, self.couleur = 0.0, P.OK
        self._img: tk.PhotoImage | None = None
        self._largeur = 0
        self._job: str | None = None
        self.bind("<Configure>", self._sur_taille)

    def definir(self, ratio: float, couleur: str) -> None:
        self.ratio, self.couleur = ratio, couleur
        self._dessiner()

    def _sur_taille(self, e) -> None:
        if abs(e.width - self._largeur) > 2:
            self._largeur = e.width
            if self._job:
                self.after_cancel(self._job)
            self._job = self.after(40, self._dessiner)

    def _dessiner(self) -> None:
        self._job = None
        largeur = max(self.theme.px(120), self._largeur or self.winfo_width())
        self._img = barre_capsule(largeur, self.hauteur, self.ratio, self.couleur)
        self.configure(image=self._img)


# ---------------------------------------------------------------------------- tableau


class Tableau(ttk.Frame):
    """Treeview stylé : tri par en-tête, lignes zébrées, défilement auto, message si vide."""

    def __init__(self, parent, theme: Theme, colonnes: list[tuple[str, str, int, str, bool]],
                 avec_icone: bool = False, hauteur: int = 10, vide: str = "Aucun élément",
                 cles_tri: dict[str, Callable[[Any], Any]] | None = None):
        """colonnes : (id, titre, largeur, alignement 'w'|'e'|'center', extensible)."""
        super().__init__(parent, style="Surface.TFrame")
        self.theme = theme
        self.cles_tri = cles_tri or {}
        self._objets: dict[str, Any] = {}
        self._valeurs: dict[str, tuple] = {}
        self._tri: tuple[str, bool] | None = None
        self._titres = {c[0]: c[1] for c in colonnes}

        self.arbre = ttk.Treeview(self, style="Tableau.Treeview", columns=[c[0] for c in colonnes],
                                  show=("tree", "headings") if avec_icone else "headings",
                                  height=hauteur, selectmode="browse")
        if avec_icone:
            self.arbre.column("#0", width=theme.px(34), minwidth=theme.px(34), stretch=False,
                              anchor="center")
            self.arbre.heading("#0", text="")
        for cid, titre, largeur, align, extensible in colonnes:
            self.arbre.column(cid, width=theme.px(largeur), minwidth=theme.px(min(largeur, 60)),
                              anchor=align, stretch=extensible)
            self.arbre.heading(cid, text=titre, anchor=align,
                               command=lambda c=cid: self.trier(c))
        self.arbre.tag_configure("impair", background=P.SURFACE_2)

        self.defil = ttk.Scrollbar(self, orient="vertical", style="Fin.Vertical.TScrollbar",
                                   command=self.arbre.yview)
        self.arbre.configure(yscrollcommand=self._defilement)
        self.arbre.grid(row=0, column=0, sticky="nsew")
        self.defil.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.msg_vide = ttk.Label(self, text=vide, style="Surface.Pale.TLabel", anchor="center",
                                  justify="center")

    def _defilement(self, debut, fin) -> None:
        if float(debut) <= 0.0 and float(fin) >= 1.0:
            self.defil.grid_remove()
        else:
            self.defil.grid()
        self.defil.set(debut, fin)

    def remplir(self, lignes: list[tuple[str, Any, tuple]], images: dict[str, tk.PhotoImage] | None = None,
                garder_selection: bool = True) -> None:
        """lignes : (iid, objet, valeurs) ; images : iid -> image (colonne icône)."""
        selection = self.selection() if garder_selection else None
        self.arbre.delete(*self.arbre.get_children())
        self._objets = {iid: obj for iid, obj, _ in lignes}
        self._valeurs = {iid: vals for iid, _, vals in lignes}
        ordre = [iid for iid, _, _ in lignes]
        if self._tri:
            ordre = self._ordonner(ordre, *self._tri)
        for n, iid in enumerate(ordre):
            kw = {"image": images[iid]} if images and iid in images else {}
            self.arbre.insert("", "end", iid=iid, values=self._valeurs[iid],
                              tags=("impair",) if n % 2 else (), **kw)
        if lignes:
            self.msg_vide.place_forget()
        else:
            self.msg_vide.place(relx=0.5, rely=0.5, anchor="center")
        if selection and self.arbre.exists(selection):
            self.arbre.selection_set(selection)
            self.arbre.see(selection)

    def _ordonner(self, ordre: list[str], colonne: str, inverse: bool) -> list[str]:
        cle = self.cles_tri.get(colonne)
        idx = list(self.arbre["columns"]).index(colonne)
        if cle:
            f = lambda iid: cle(self._objets[iid])            # noqa: E731
        else:
            f = lambda iid: str(self._valeurs[iid][idx]).casefold()  # noqa: E731
        return sorted(ordre, key=f, reverse=inverse)

    def trier(self, colonne: str) -> None:
        inverse = bool(self._tri and self._tri[0] == colonne and not self._tri[1])
        self._tri = (colonne, inverse)
        for cid, titre in self._titres.items():
            fleche = (" ▼" if inverse else " ▲") if cid == colonne else ""
            self.arbre.heading(cid, text=titre + fleche)
        ordre = self._ordonner(list(self.arbre.get_children()), colonne, inverse)
        for n, iid in enumerate(ordre):
            self.arbre.move(iid, "", n)
            self.arbre.item(iid, tags=("impair",) if n % 2 else ())

    def selection(self) -> str | None:
        sel = self.arbre.selection()
        return sel[0] if sel else None

    def objet_selectionne(self) -> Any:
        iid = self.selection()
        return self._objets.get(iid) if iid else None

    def selectionner(self, iid: str) -> None:
        if self.arbre.exists(iid):
            self.arbre.selection_set(iid)
            self.arbre.focus(iid)
            self.arbre.see(iid)

    def premier(self) -> str | None:
        enfants = self.arbre.get_children()
        return enfants[0] if enfants else None


# ---------------------------------------------------------------------------- onglets


class Onglets(ttk.Frame):
    """Barre d'onglets épurée : texte + soulignement accentué sous l'onglet actif."""

    def __init__(self, parent, theme: Theme, sur_changement: Callable[[str], None] | None = None):
        super().__init__(parent, style="Surface.TFrame")
        self.theme = theme
        self.barre = ttk.Frame(self, style="Surface.TFrame")
        self.barre.pack(fill="x")
        ttk.Frame(self, style="Separateur.TFrame", height=1).pack(fill="x")
        self.contenu = ttk.Frame(self, style="Surface.TFrame")
        self.contenu.pack(fill="both", expand=True)
        self.contenu.rowconfigure(0, weight=1)
        self.contenu.columnconfigure(0, weight=1)
        self._onglets: dict[str, tuple[ttk.Label, ttk.Frame, ttk.Frame]] = {}
        self.actif: str | None = None
        self.sur_changement = sur_changement

    def ajouter(self, cle: str, titre: str) -> ttk.Frame:
        bloc = ttk.Frame(self.barre, style="Surface.TFrame")
        bloc.pack(side="left", padx=(0, self.theme.px(22)))
        lbl = ttk.Label(bloc, text=titre, style="Onglet.TLabel", cursor="hand2")
        lbl.pack()
        trait = ttk.Frame(bloc, style="Surface.TFrame", height=self.theme.px(3))
        trait.pack(fill="x")
        page = ttk.Frame(self.contenu, style="Surface.TFrame")
        page.grid(row=0, column=0, sticky="nsew")
        lbl.bind("<Button-1>", lambda e: self.afficher(cle))
        self._onglets[cle] = (lbl, trait, page)
        self.afficher(self.actif or cle, notifier=False)
        return page

    def titre(self, cle: str, texte: str) -> None:
        self._onglets[cle][0].configure(text=texte)

    def afficher(self, cle: str, notifier: bool = True) -> None:
        for k, (lbl, trait, page) in self._onglets.items():
            actif = k == cle
            lbl.configure(style="OngletActif.TLabel" if actif else "Onglet.TLabel")
            trait.configure(style="Accent.TFrame" if actif else "Surface.TFrame")
            if actif:
                page.tkraise()
        self.actif = cle
        if notifier and self.sur_changement:
            self.sur_changement(cle)


# ---------------------------------------------------------------------------- saisie


class ZoneTexte(tk.Text):
    """Zone de texte multiligne assortie aux champs ttk."""

    def __init__(self, parent, theme: Theme, hauteur: int = 3, **kw):
        super().__init__(parent, height=hauteur, wrap="word", relief="flat", font=theme.f_corps,
                         background=P.SURFACE, foreground=P.TEXTE, insertbackground=P.TEXTE,
                         selectbackground=P.SELECTION, highlightthickness=1,
                         highlightbackground=P.BORDURE_FORTE, highlightcolor=P.ACCENT,
                         padx=theme.px(8), pady=theme.px(6), undo=True, **kw)
        self.bind("<Tab>", self._tab_suivant)
        self.bind("<Shift-Tab>", self._tab_precedent)

    def _tab_suivant(self, _e):
        self.tk_focusNext().focus_set()
        return "break"

    def _tab_precedent(self, _e):
        self.tk_focusPrev().focus_set()
        return "break"

    def valeur(self) -> str:
        return self.get("1.0", "end-1c").strip()

    def definir(self, texte: str) -> None:
        self.delete("1.0", "end")
        self.insert("1.0", texte or "")

    def activer(self, actif: bool) -> None:
        self.configure(state="normal" if actif else "disabled",
                       background=P.SURFACE if actif else P.SURFACE_2)


class ChampRecherche(ttk.Entry):
    """Champ de recherche avec texte indicatif."""

    def __init__(self, parent, indication: str, sur_saisie: Callable[[str], None], **kw):
        self.var = tk.StringVar()
        super().__init__(parent, textvariable=self.var, style="Recherche.TEntry", **kw)
        self.indication = indication
        self._vide = True
        self._sur_saisie = sur_saisie
        self._job: str | None = None
        self._afficher_indication()
        self.bind("<FocusIn>", self._focus_entree)
        self.bind("<FocusOut>", self._focus_sortie)
        self.bind("<Escape>", lambda e: self.effacer())
        self.var.trace_add("write", self._modifie)

    def _afficher_indication(self) -> None:
        self._vide = True
        self.var.set(self.indication)
        self.configure(foreground=P.TEXTE_3)

    def _focus_entree(self, _e) -> None:
        if self._vide:
            self._vide = False
            self.var.set("")
            self.configure(foreground=P.TEXTE)

    def _focus_sortie(self, _e) -> None:
        if not self.var.get():
            self._afficher_indication()

    def _modifie(self, *_a) -> None:
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(120, lambda: self._sur_saisie(self.texte()))

    def texte(self) -> str:
        return "" if self._vide else self.var.get().strip()

    def effacer(self) -> None:
        self.var.set("")
        if self.focus_get() is not self:
            self._afficher_indication()


def infobulle(widget: tk.Widget, texte: str) -> None:
    """Petite bulle d'aide au survol."""
    etat: dict[str, Any] = {"fen": None, "job": None}

    def montrer():
        x = widget.winfo_rootx() + 8
        y = widget.winfo_rooty() + widget.winfo_height() + 4
        fen = tk.Toplevel(widget)
        fen.wm_overrideredirect(True)
        fen.wm_geometry(f"+{x}+{y}")
        tk.Label(fen, text=texte, background=P.ENTETE, foreground="#FFFFFF", padx=8, pady=4,
                 font="Petit", justify="left").pack()
        etat["fen"] = fen

    def entrer(_e):
        etat["job"] = widget.after(500, montrer)

    def sortir(_e):
        if etat["job"]:
            widget.after_cancel(etat["job"])
            etat["job"] = None
        if etat["fen"]:
            etat["fen"].destroy()
            etat["fen"] = None

    widget.bind("<Enter>", entrer, add="+")
    widget.bind("<Leave>", sortir, add="+")
    widget.bind("<ButtonPress>", sortir, add="+")
