"""Fenêtre principale."""

from __future__ import annotations

import logging
import os
import sqlite3
import subprocess
import sys
import tkinter as tk
import traceback
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .. import APP_NOM, NB_PARAMETRES, VERSION
from ..config import dossier_ressources, ecrire_dossier_base
from ..db import Base, Configuration, ErreurMetier, MaquetteResume, Vol
from ..export import exporter_tout
from ..formats import format_date, format_duree, format_horodatage
from ..verrou import Verrou
from .dialogs import (DialogueConfiguration, DialogueDossier, DialogueMaquette, DialogueReglages,
                      DialogueSuppressionMaquette, DialogueSuppressionVol, DialogueVol)
from .theme import P, Theme
from .widgets import BarrePotentiel, ChampRecherche, Onglets, Tableau, couleur_etat, infobulle, pastille

log = logging.getLogger(__name__)


def ouvrir_dans_explorateur(chemin: Path) -> None:
    try:
        if sys.platform == "win32":
            os.startfile(chemin)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(chemin)])
    except OSError as e:
        messagebox.showerror(APP_NOM, f"Impossible d'ouvrir le dossier :\n{e}")


class Application:
    def __init__(self, root: tk.Tk, theme: Theme, base: Base, verrou: Verrou):
        self.root, self.theme, self.base, self.verrou = root, theme, base, verrou
        self.maquettes: list[MaquetteResume] = []
        self.courante: MaquetteResume | None = None
        self._hist: list[Configuration] = []
        self._toast_job: str | None = None
        self._affichage_prevu = False
        self.noms = base.noms_parametres()
        self.seuil = base.seuil_alerte()
        px = theme.px
        self._pastilles = {c: pastille(c, px(14)) for c in (P.OK, P.ALERTE, P.DANGER)}

        root.title(APP_NOM)
        root.protocol("WM_DELETE_WINDOW", self.quitter)
        root.report_callback_exception = self._erreur_inattendue
        self._construire()
        self._raccourcis()
        self.charger()
        self._appliquer_mode()
        self._positionner()
        root.after(3000, self._surveiller_verrou)

    # ====================================================================== construction
    def _construire(self) -> None:
        self._entete()
        self._barre_etat()
        corps = ttk.Frame(self.root, padding=self.theme.px(16))
        corps.pack(fill="both", expand=True)
        paned = ttk.Panedwindow(corps, orient="horizontal")
        paned.pack(fill="both", expand=True)
        paned.add(self._panneau_liste(paned), weight=2)
        paned.add(self._panneau_detail(paned), weight=3)

    def _entete(self) -> None:
        px = self.theme.px
        bar = ttk.Frame(self.root, style="Entete.TFrame", padding=(px(20), px(12)))
        bar.pack(fill="x")
        self._logo = None
        for taille in (48, 40, 32, 24):
            if taille <= px(30) or taille == 24:
                f = dossier_ressources() / "assets" / f"logo_{taille}.png"
                if f.exists():
                    self._logo = tk.PhotoImage(file=str(f))
                    break
        if self._logo:
            ttk.Label(bar, image=self._logo, style="EnteteTitre.TLabel").pack(side="left", padx=(0, px(12)))
        titres = ttk.Frame(bar, style="Entete.TFrame")
        titres.pack(side="left")
        ttk.Label(titres, text=APP_NOM, style="EnteteTitre.TLabel").pack(anchor="w")
        self.l_asso = ttk.Label(titres, text="", style="EnteteSous.TLabel")
        self.l_asso.pack(anchor="w")

        self.b_reglages = ttk.Button(bar, text="Réglages", style="Entete.TButton", command=self.reglages)
        self.b_reglages.pack(side="right")
        self.b_export = ttk.Button(bar, text="Exporter (CSV)", style="Entete.TButton", command=self.exporter)
        self.b_export.pack(side="right", padx=(0, px(6)))
        self.b_actualiser = ttk.Button(bar, text="Actualiser", style="Entete.TButton",
                                       command=self.actualiser)
        self.b_actualiser.pack(side="right", padx=(0, px(6)))
        infobulle(self.b_actualiser, "Recharger les données (F5)")
        infobulle(self.b_export, "Exporter maquettes, configurations et vols pour Excel (Ctrl+E)")
        self.badge = ttk.Label(bar, text="LECTURE SEULE", style="BadgeEntete.TLabel")
        self.badge_place = dict(side="right", padx=(0, px(16)))

    def _barre_etat(self) -> None:
        px = self.theme.px
        bar = ttk.Frame(self.root, style="Surface.TFrame")
        bar.pack(side="bottom", fill="x")
        ttk.Frame(bar, style="Separateur.TFrame", height=1).pack(fill="x")
        ligne = ttk.Frame(bar, style="Surface.TFrame", padding=(px(16), px(5)))
        ligne.pack(fill="x")
        self.l_base = ttk.Label(ligne, text=f"Base : {self.base.chemin}", style="Surface.Pale.TLabel")
        self.l_base.pack(side="left")
        self.l_version = ttk.Label(ligne, text=f"v{VERSION}", style="Surface.Pale.TLabel")
        self.l_version.pack(side="right")
        self.l_mode = ttk.Label(ligne, text="", style="Surface.Pale.TLabel")
        self.l_mode.pack(side="right", padx=(0, px(18)))
        self.l_toast = ttk.Label(ligne, text="", style="Surface.Modifie.TLabel")
        self.l_toast.pack(side="left", padx=(px(24), 0))

    def _panneau_liste(self, parent) -> ttk.Frame:
        px = self.theme.px
        carte = ttk.Frame(parent, style="Carte.TFrame", padding=(px(16), px(14)))
        haut = ttk.Frame(carte, style="Surface.TFrame")
        haut.pack(fill="x")
        ttk.Label(haut, text="Maquettes", style="Surface.SousTitre.TLabel").pack(side="left")
        self.l_compte = ttk.Label(haut, text="", style="BadgeAccent.TLabel")
        self.l_compte.pack(side="left", padx=(px(8), 0))
        self.b_nouvelle = ttk.Button(haut, text="+  Nouvelle maquette", style="Accent.TButton",
                                     command=self.nouvelle_maquette)
        self.b_nouvelle.pack(side="right")
        infobulle(self.b_nouvelle, "Ctrl+N")

        self.recherche = ChampRecherche(carte, "Rechercher un n° de série, un paramètre…",
                                        lambda t: self.filtrer())
        self.recherche.pack(fill="x", pady=(px(12), px(10)))

        self.t_maquettes = Tableau(
            carte, self.theme, avec_icone=True, hauteur=14,
            vide="Aucune maquette.\nCréez la première avec « Nouvelle maquette ».",
            colonnes=[("num", "N° de série", 130, "w", True), ("conf", "Config.", 58, "center", False),
                      ("restant", "Restant", 84, "e", False), ("pct", "%", 52, "e", False),
                      ("vol", "Dernier vol", 92, "center", False)],
            cles_tri={"num": lambda m: m.numero_serie.casefold(), "conf": lambda m: m.version,
                      "restant": lambda m: m.restant,
                      "pct": lambda m: m.restant / m.alloue if m.alloue else 0,
                      "vol": lambda m: m.dernier_vol or ""})
        self.t_maquettes.pack(fill="both", expand=True)
        self.t_maquettes.arbre.bind("<<TreeviewSelect>>", lambda e: self._planifier_affichage())

        legende = ttk.Frame(carte, style="Surface.TFrame")
        legende.pack(fill="x", pady=(px(10), 0))
        self.l_legende = []
        for couleur in (P.OK, P.ALERTE, P.DANGER):
            lbl = ttk.Label(legende, image=self._pastilles[couleur], compound="left",
                            style="Surface.Pale.TLabel")
            lbl.pack(side="left", padx=(0, px(14)))
            self.l_legende.append(lbl)
        return carte

    def _panneau_detail(self, parent) -> ttk.Frame:
        px = self.theme.px
        carte = ttk.Frame(parent, style="Carte.TFrame", padding=(px(22), px(18)))
        carte.rowconfigure(0, weight=1)
        carte.columnconfigure(0, weight=1)

        # --- état vide
        self.f_vide = ttk.Frame(carte, style="Surface.TFrame")
        self.f_vide.grid(row=0, column=0, sticky="nsew")
        centre = ttk.Frame(self.f_vide, style="Surface.TFrame")
        centre.place(relx=0.5, rely=0.42, anchor="center")
        self.l_vide_titre = ttk.Label(centre, text="", style="Surface.SousTitre.TLabel")
        self.l_vide_titre.pack()
        self.l_vide_texte = ttk.Label(centre, text="", style="Surface.Gris.TLabel", justify="center")
        self.l_vide_texte.pack(pady=(px(6), px(14)))
        self.b_vide = ttk.Button(centre, text="+  Nouvelle maquette", style="Accent.TButton",
                                 command=self.nouvelle_maquette)

        # --- détail
        d = self.f_detail = ttk.Frame(carte, style="Surface.TFrame")
        d.grid(row=0, column=0, sticky="nsew")
        d.columnconfigure(0, weight=1)
        d.rowconfigure(3, weight=1)

        haut = ttk.Frame(d, style="Surface.TFrame")
        haut.grid(row=0, column=0, sticky="ew")
        haut.columnconfigure(0, weight=1)
        self.l_num = ttk.Label(haut, text="", style="Surface.Titre.TLabel")
        self.l_num.grid(row=0, column=0, sticky="w")
        self.l_sous = ttk.Label(haut, text="", style="Surface.Gris.TLabel")
        self.l_sous.grid(row=1, column=0, columnspan=2, sticky="w", pady=(px(2), 0))
        actions = ttk.Frame(haut, style="Surface.TFrame")
        actions.grid(row=0, column=1, sticky="e")
        self.b_suppr = ttk.Button(actions, text="Supprimer", style="DangerLeger.TButton",
                                  command=self.supprimer_maquette)
        self.b_suppr.pack(side="right")
        self.b_vol = ttk.Button(actions, text="Enregistrer un vol", style="Accent.TButton",
                                command=self.enregistrer_vol)
        self.b_vol.pack(side="right", padx=(0, px(8)))
        self.b_config = ttk.Button(actions, text="Nouvelle configuration",
                                   command=self.nouvelle_configuration)
        self.b_config.pack(side="right", padx=(0, px(8)))

        # --- potentiel
        pot = ttk.Frame(d, style="Surface.TFrame")
        pot.grid(row=1, column=0, sticky="ew", pady=(px(18), px(6)))
        self.tuiles = {}
        for i, (cle, titre) in enumerate((("alloue", "HEURES ALLOUÉES"), ("consomme", "CONSOMMÉES"),
                                          ("restant", "RESTANTES"))):
            pot.columnconfigure(i, weight=1, uniform="tuile")
            t = ttk.Frame(pot, style="Tuile.TFrame", padding=(px(16), px(12)))
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(10), 0))
            ttk.Label(t, text=titre, style="Surface2.Libelle.TLabel").pack(anchor="w")
            v = ttk.Label(t, text="", style="Surface2.Chiffre.TLabel")
            v.pack(anchor="w", pady=(px(2), 0))
            s = ttk.Label(t, text="", style="Surface2.Pale.TLabel")
            s.pack(anchor="w")
            self.tuiles[cle] = (v, s)
        style = ttk.Style(self.root)
        for nom, couleur in (("OK", P.OK), ("Alerte", P.ALERTE), ("Danger", P.DANGER)):
            style.configure(f"Restant{nom}.TLabel", background=P.SURFACE_2, foreground=couleur,
                            font=self.theme.f_chiffre)
        self.barre = BarrePotentiel(d, self.theme, hauteur=8)
        self.barre.grid(row=2, column=0, sticky="ew", pady=(px(4), px(16)))

        # --- onglets
        self.onglets = Onglets(d, self.theme)
        self.onglets.grid(row=3, column=0, sticky="nsew")
        self._page_configuration(self.onglets.ajouter("config", "Configuration actuelle"))
        self._page_historique(self.onglets.ajouter("hist", "Historique"))
        self._page_vols(self.onglets.ajouter("vols", "Carnet de vols"))
        return carte

    def _page_configuration(self, page: ttk.Frame) -> None:
        px = self.theme.px
        grille = ttk.Frame(page, style="Surface.TFrame")
        grille.pack(fill="x", pady=(px(14), 0))
        self.cellules: list[tuple[ttk.Label, ttk.Label]] = []
        for i in range(NB_PARAMETRES):
            ligne, col = divmod(i, 3)
            grille.columnconfigure(col, weight=1, uniform="p")
            c = ttk.Frame(grille, style="Tuile.TFrame", padding=(px(14), px(10)))
            c.grid(row=ligne, column=col, sticky="nsew",
                   padx=(0 if col == 0 else px(10), 0), pady=(0, px(10)))
            n = ttk.Label(c, text="", style="Surface2.Libelle.TLabel")
            n.pack(anchor="w")
            v = ttk.Label(c, text="", style="Surface2.Semi.TLabel", wraplength=px(200), justify="left")
            v.pack(anchor="w", pady=(px(3), 0))
            self.cellules.append((n, v))
        self.l_config_info = ttk.Label(page, text="", style="Surface.Gris.TLabel", wraplength=px(700),
                                       justify="left")
        self.l_config_info.pack(anchor="w", pady=(px(4), 0))

    def _page_historique(self, page: ttk.Frame) -> None:
        px = self.theme.px
        self.t_hist = Tableau(
            page, self.theme, hauteur=6, vide="Aucune configuration.",
            colonnes=[("ver", "Version", 70, "center", False), ("date", "Date", 92, "center", False),
                      ("type", "Type", 120, "w", True), ("objet", "Objet", 160, "w", True),
                      ("dem", "Demandeur", 110, "w", True), ("aut", "Auteur", 110, "w", True)],
            cles_tri={"ver": lambda c: c.version, "date": lambda c: (c.date_effet, c.version)})
        self.t_hist.pack(fill="x", pady=(px(12), 0))
        self.t_hist.arbre.bind("<<TreeviewSelect>>", lambda e: self._afficher_version())

        bas = ttk.Frame(page, style="Surface.TFrame")
        bas.pack(fill="x", pady=(px(12), 0))
        self.l_ver_titre = ttk.Label(bas, text="", style="Surface.Semi.TLabel")
        self.l_ver_titre.pack(anchor="w")
        self.l_ver_info = ttk.Label(bas, text="", style="Surface.Gris.TLabel", wraplength=px(700),
                                    justify="left")
        self.l_ver_info.pack(anchor="w", pady=(px(2), px(8)))
        grille = ttk.Frame(bas, style="Surface.TFrame")
        grille.pack(fill="x")
        self.cellules_ver: list[tuple[ttk.Label, ttk.Label, ttk.Label]] = []
        for i in range(NB_PARAMETRES):
            ligne, col = divmod(i, 3)
            grille.columnconfigure(col, weight=1, uniform="v")
            c = ttk.Frame(grille, style="Surface.TFrame")
            c.grid(row=ligne, column=col, sticky="nw", pady=(0, px(6)))
            n = ttk.Label(c, text="", style="Surface.Pale.TLabel")
            n.pack(anchor="w")
            v = ttk.Label(c, text="", style="Surface.TLabel", wraplength=px(200), justify="left")
            v.pack(anchor="w")
            a = ttk.Label(c, text="", style="Surface.Pale.TLabel", wraplength=px(200), justify="left")
            self.cellules_ver.append((n, v, a))

    def _page_vols(self, page: ttk.Frame) -> None:
        px = self.theme.px
        self.t_vols = Tableau(
            page, self.theme, hauteur=8, vide="Aucun vol enregistré pour cette maquette.",
            colonnes=[("date", "Date", 92, "center", False), ("duree", "Durée", 80, "e", False),
                      ("equipe", "Équipe", 140, "w", True), ("comm", "Commentaire", 230, "w", True),
                      ("saisi", "Saisi le", 124, "center", False)],
            cles_tri={"date": lambda v: (v.date_vol, v.id), "duree": lambda v: v.duree,
                      "saisi": lambda v: v.saisi_le})
        self.t_vols.pack(fill="both", expand=True, pady=(px(12), 0))
        self.t_vols.arbre.bind("<<TreeviewSelect>>", lambda e: self._sur_selection_vol())
        self.t_vols.arbre.bind("<Delete>", lambda e: self.supprimer_vol())
        bas = ttk.Frame(page, style="Surface.TFrame")
        bas.pack(fill="x", pady=(px(10), 0))
        self.b_suppr_vol = ttk.Button(bas, text="Supprimer ce vol", style="DangerLeger.TButton",
                                      command=self.supprimer_vol)
        self.b_suppr_vol.pack(side="right", anchor="n")
        self.l_vol_detail = ttk.Label(bas, text="", style="Surface.Gris.TLabel", wraplength=px(560),
                                      justify="left")
        self.l_vol_detail.pack(side="left", fill="x", expand=True, anchor="n")

    def _raccourcis(self) -> None:
        r = self.root
        r.bind("<Control-n>", lambda e: self.nouvelle_maquette())
        r.bind("<Control-N>", lambda e: self.nouvelle_maquette())
        r.bind("<Control-f>", lambda e: self.recherche.focus_set())
        r.bind("<Control-F>", lambda e: self.recherche.focus_set())
        r.bind("<Control-e>", lambda e: self.exporter())
        r.bind("<Control-E>", lambda e: self.exporter())
        r.bind("<F5>", lambda e: self.actualiser())

    def _positionner(self) -> None:
        r = self.root
        r.update_idletasks()
        sl, sh = r.winfo_screenwidth(), r.winfo_screenheight()
        px = self.theme.px
        r.minsize(min(px(1020), sl), min(px(660), sh - 60))
        l, h = min(px(1440), int(sl * 0.9)), min(px(900), int(sh * 0.86))
        r.geometry(f"{l}x{h}+{(sl - l) // 2}+{max(0, (sh - h) // 3)}")
        if sl < px(1280) or sh < px(760):
            try:
                r.state("zoomed")
            except tk.TclError:
                pass

    # ====================================================================== données
    def charger(self, selection: int | None = None) -> None:
        if selection is None and self.courante:
            selection = self.courante.id
        self.noms = self.base.noms_parametres()
        self.seuil = self.base.seuil_alerte()
        self.maquettes = self.base.liste_maquettes()
        asso = self.base.reglage("nom_asso", "")
        self.l_asso.configure(text=asso or "Configurations et potentiel de vol")
        self.root.title(f"{APP_NOM} — {asso}" if asso else APP_NOM)
        textes = (f"≥ {self.seuil} %", f"< {self.seuil} %", "épuisé")
        for lbl, t in zip(self.l_legende, textes):
            lbl.configure(text=f" {t}")
        self.filtrer(selection)

    def filtrer(self, selection: int | None = None) -> None:
        q = self.recherche.texte().casefold()
        visibles = [m for m in self.maquettes
                    if not q or q in m.numero_serie.casefold()
                    or any(q in p.casefold() for p in m.parametres)]
        lignes, images = [], {}
        for m in visibles:
            iid = str(m.id)
            pct = max(0.0, m.restant * 100 / m.alloue) if m.alloue else 0.0
            lignes.append((iid, m, (m.numero_serie, f"v{m.version}", format_duree(m.restant),
                                    f"{pct:.0f} %", format_date(m.dernier_vol) or "—")))
            images[iid] = self._pastilles[couleur_etat(m.restant, m.alloue, self.seuil)]
        self.t_maquettes.remplir(lignes, images)
        n, total = len(visibles), len(self.maquettes)
        self.l_compte.configure(text=str(total) if n == total else f"{n} / {total}")
        if q and not visibles:
            self.t_maquettes.msg_vide.configure(text="Aucun résultat pour cette recherche.")
            self.t_maquettes.msg_vide.place(relx=0.5, rely=0.5, anchor="center")
        else:
            self.t_maquettes.msg_vide.configure(
                text="Aucune maquette.\nCréez la première avec « Nouvelle maquette ».")

        cible = str(selection) if selection is not None else self.t_maquettes.selection()
        if cible and self.t_maquettes.arbre.exists(cible):
            self.t_maquettes.selectionner(cible)
        elif (premier := self.t_maquettes.premier()):
            self.t_maquettes.selectionner(premier)
        self.courante = self.t_maquettes.objet_selectionne()
        self._planifier_affichage()

    def _planifier_affichage(self) -> None:
        """Regroupe les rafraîchissements du détail en un seul (évite les requêtes en double)."""
        if not self._affichage_prevu:
            self._affichage_prevu = True
            self.root.after_idle(self._sur_selection)

    def _sur_selection(self) -> None:
        self._affichage_prevu = False
        m = self.t_maquettes.objet_selectionne()
        self.courante = m
        if m is None:
            if self.maquettes:
                self.l_vide_titre.configure(text="Aucune maquette sélectionnée")
                self.l_vide_texte.configure(text="Sélectionnez une maquette dans la liste.")
                self.b_vide.pack_forget()
            else:
                self.l_vide_titre.configure(text="Bienvenue")
                self.l_vide_texte.configure(
                    text="Aucune maquette n'est encore enregistrée.\n"
                         "Ajoutez-en une pour suivre sa configuration et son potentiel de vol.")
                if not self.base.lecture_seule:
                    self.b_vide.pack()
            self.f_vide.tkraise()
        else:
            self._afficher_detail(m)
            self.f_detail.tkraise()
        self._appliquer_mode()

    def _afficher_detail(self, m: MaquetteResume) -> None:
        self._hist = self.base.configurations(m.id)
        vols = self.base.vols(m.id)
        actuelle = self._hist[0]

        self.l_num.configure(text=m.numero_serie)
        self.l_sous.configure(
            text=f"Configuration v{m.version}  ·  en vigueur depuis le {format_date(actuelle.date_effet)}"
                 f"  ·  par {actuelle.auteur}")

        couleur = couleur_etat(m.restant, m.alloue, self.seuil)
        nom_style = {P.OK: "OK", P.ALERTE: "Alerte", P.DANGER: "Danger"}[couleur]
        pct = m.restant * 100 / m.alloue if m.alloue else 0
        self.tuiles["alloue"][0].configure(text=format_duree(m.alloue))
        self.tuiles["alloue"][1].configure(text="Potentiel total")
        self.tuiles["consomme"][0].configure(text=format_duree(m.consomme))
        self.tuiles["consomme"][1].configure(
            text=f"{m.nb_vols} vol{'s' if m.nb_vols > 1 else ''}"
                 + (f"  ·  dernier le {format_date(m.dernier_vol)}" if m.dernier_vol else ""))
        self.tuiles["restant"][0].configure(text=format_duree(m.restant), style=f"Restant{nom_style}.TLabel")
        self.tuiles["restant"][1].configure(
            text="Potentiel épuisé" if m.restant <= 0 else f"{pct:.0f} % du potentiel")
        self.barre.definir(max(0.0, m.restant / m.alloue) if m.alloue else 0.0, couleur)

        for (n, v), nom, val in zip(self.cellules, self.noms, actuelle.parametres):
            n.configure(text=nom.upper())
            v.configure(text=val or "—")
        info = f"Dernière modification : {format_date(actuelle.date_effet)} par {actuelle.auteur}"
        if actuelle.version > 1:
            info += f"  ·  {actuelle.type}  ·  {actuelle.objet}"
        self.l_config_info.configure(text=info)

        self.t_hist.remplir([(str(c.id), c, (f"v{c.version}", format_date(c.date_effet), c.type,
                                              c.objet, c.demandeur, c.auteur)) for c in self._hist],
                            garder_selection=False)
        self.t_hist.selectionner(str(actuelle.id))
        self._afficher_version()

        self.t_vols.remplir([(str(v.id), v, (format_date(v.date_vol), format_duree(v.duree), v.equipe,
                                             v.commentaire.replace("\n", "  "),
                                             format_horodatage(v.saisi_le))) for v in vols],
                            garder_selection=False)
        self._sur_selection_vol()
        self.onglets.titre("hist", f"Historique ({len(self._hist)})")
        self.onglets.titre("vols", f"Carnet de vols ({len(vols)})")

    def _afficher_version(self) -> None:
        conf = self.t_hist.objet_selectionne()
        if conf is None:
            self.l_ver_titre.configure(text="")
            self.l_ver_info.configure(text="")
            for n, v, a in self.cellules_ver:
                n.configure(text="")
                v.configure(text="")
                a.pack_forget()
            return
        idx = next(i for i, c in enumerate(self._hist) if c.id == conf.id)
        precedente = self._hist[idx + 1] if idx + 1 < len(self._hist) else None
        modifies = [] if precedente is None else [
            i for i in range(NB_PARAMETRES) if conf.parametres[i] != precedente.parametres[i]]
        if precedente is None:
            titre = f"Version v{conf.version}  ·  configuration initiale"
        else:
            nb = len(modifies)
            titre = (f"Version v{conf.version}  ·  {nb} paramètre{'s' if nb > 1 else ''} "
                     f"modifié{'s' if nb > 1 else ''} par rapport à v{precedente.version}")
        self.l_ver_titre.configure(text=titre)
        details = [f"Saisi le {format_horodatage(conf.saisi_le)}"]
        if conf.demandeur:
            details.append(f"demandé par {conf.demandeur}")
        texte = "  ·  ".join(details)
        if conf.commentaire:
            texte += f"\nCommentaire : {conf.commentaire}"
        self.l_ver_info.configure(text=texte)
        for i, ((n, v, a), nom) in enumerate(zip(self.cellules_ver, self.noms)):
            modifie = i in modifies
            n.configure(text=nom + ("   ● modifié" if modifie else ""),
                        style="Surface.Modifie.TLabel" if modifie else "Surface.Pale.TLabel")
            v.configure(text=conf.parametres[i] or "—",
                        style="Surface.Semi.TLabel" if modifie else "Surface.TLabel")
            if modifie and precedente is not None:
                a.configure(text=f"avant : {precedente.parametres[i] or '(vide)'}")
                a.pack(anchor="w")
            else:
                a.pack_forget()

    def _sur_selection_vol(self) -> None:
        v: Vol | None = self.t_vols.objet_selectionne()
        if v is None:
            self.l_vol_detail.configure(text="Sélectionnez un vol pour voir son commentaire complet.")
        else:
            self.l_vol_detail.configure(
                text=f"Vol du {format_date(v.date_vol)}  ·  {format_duree(v.duree)}  ·  {v.equipe}"
                     + (f"\n{v.commentaire}" if v.commentaire else ""))
        self._appliquer_mode()

    # ====================================================================== mode écriture / lecture
    def _appliquer_mode(self) -> None:
        ecriture = not self.base.lecture_seule
        etat = "normal" if ecriture else "disabled"
        self.b_nouvelle.configure(state=etat)
        a_maquette = self.courante is not None
        for b in (self.b_config, self.b_vol, self.b_suppr):
            b.configure(state="normal" if ecriture and a_maquette else "disabled")
        self.b_suppr_vol.configure(
            state="normal" if ecriture and self.t_vols.selection() else "disabled")
        if ecriture:
            self.badge.pack_forget()
            self.l_mode.configure(text="●  Connecté en écriture")
        else:
            self.badge.pack(**self.badge_place)
            self.l_mode.configure(text="Lecture seule  ·  F5 pour actualiser")
            self.b_vide.pack_forget()

    def _peut_ecrire(self) -> bool:
        if self.base.lecture_seule:
            messagebox.showinfo(APP_NOM, "L'application est ouverte en lecture seule.", parent=self.root)
            return False
        if not self.verrou.est_a_nous():
            self._basculer_lecture_seule()
            return False
        return True

    def _surveiller_verrou(self) -> None:
        if not self.base.lecture_seule and self.verrou.perdu:
            self._basculer_lecture_seule()
        self.root.after(3000, self._surveiller_verrou)

    def _basculer_lecture_seule(self) -> None:
        if self.base.lecture_seule:
            return
        self.base.passer_en_lecture_seule()
        self._appliquer_mode()
        info = self.verrou.lire()
        qui = f"{info.utilisateur} (poste {info.poste})" if info else "Un autre utilisateur"
        messagebox.showwarning(
            APP_NOM, f"{qui} a pris la main sur la base.\n\nVotre session passe en lecture seule. "
                     "Tout ce que vous aviez enregistré est conservé.", parent=self.root)

    # ====================================================================== actions
    def toast(self, texte: str) -> None:
        self.l_toast.configure(text=f"✓  {texte}")
        if self._toast_job:
            self.root.after_cancel(self._toast_job)
        self._toast_job = self.root.after(6000, lambda: self.l_toast.configure(text=""))

    def nouvelle_maquette(self) -> None:
        if not self._peut_ecrire():
            return
        def action(d):
            return self.base.creer_maquette(d["numero"], d["alloue"], d["parametres"], d["trace"])
        mid = DialogueMaquette(self.root, self.theme, self.noms, action).montrer()
        if mid:
            self.recherche.effacer()
            self.charger(mid)
            self.onglets.afficher("config")
            self.toast(f"Maquette {self.courante.numero_serie if self.courante else ''} créée")

    def nouvelle_configuration(self) -> None:
        m = self.courante
        if m is None or not self._peut_ecrire():
            return
        def action(d):
            return self.base.nouvelle_configuration(m.id, d["parametres"], d["trace"])
        version = DialogueConfiguration(self.root, self.theme, self.noms, m, action).montrer()
        if version:
            self.charger(m.id)
            self.onglets.afficher("hist")
            self.toast(f"Configuration v{version} enregistrée pour {m.numero_serie}")

    def enregistrer_vol(self) -> None:
        m = self.courante
        if m is None or not self._peut_ecrire():
            return
        def action(d):
            return self.base.ajouter_vol(m.id, d["date"], d["duree"], d["equipe"], d["commentaire"])
        if DialogueVol(self.root, self.theme, m, self.seuil, action).montrer():
            self.charger(m.id)
            self.onglets.afficher("vols")
            restant = self.courante.restant if self.courante else 0
            self.toast(f"Vol enregistré  ·  restant {format_duree(restant)}")

    def supprimer_maquette(self) -> None:
        m = self.courante
        if m is None or not self._peut_ecrire():
            return
        nb_c, nb_v = self.base.compter_dependances(m.id)
        def action(_):
            self.base.supprimer_maquette(m.id)
            return True
        if DialogueSuppressionMaquette(self.root, self.theme, m, nb_c, nb_v, action).montrer():
            self.courante = None
            self.charger()
            self.toast(f"Maquette {m.numero_serie} supprimée (sauvegarde effectuée avant)")

    def supprimer_vol(self) -> None:
        m, v = self.courante, self.t_vols.objet_selectionne()
        if m is None or v is None or not self._peut_ecrire():
            return
        def action(_):
            self.base.supprimer_vol(v.id)
            return True
        if DialogueSuppressionVol(self.root, self.theme, m.numero_serie, v, action).montrer():
            self.charger(m.id)
            self.onglets.afficher("vols")
            self.toast(f"Vol du {format_date(v.date_vol)} supprimé ({format_duree(v.duree)} recréditées)")

    def actualiser(self) -> None:
        self.charger()
        self.toast("Données actualisées")

    def exporter(self) -> None:
        dossier = filedialog.askdirectory(parent=self.root, title="Dossier où enregistrer l'export CSV",
                                          initialdir=str(Path.home() / "Documents"))
        if not dossier:
            return
        fichiers = exporter_tout(self.base, Path(dossier))
        self.toast(f"Export terminé : {len(fichiers)} fichiers CSV")
        if messagebox.askyesno(APP_NOM, "Export terminé :\n\n" + "\n".join(f.name for f in fichiers)
                               + "\n\nOuvrir le dossier ?", parent=self.root):
            ouvrir_dans_explorateur(Path(dossier))

    def reglages(self) -> None:
        dlg: DialogueReglages | None = None

        def ouvrir():
            ouvrir_dans_explorateur(self.base.dossier)

        def sauvegarder():
            if not self._peut_ecrire():
                return
            f = self.base.sauvegarder("manuelle")
            messagebox.showinfo(APP_NOM, f"Sauvegarde créée :\n{f}", parent=dlg)

        def restaurer():
            if not self._peut_ecrire():
                return
            f = filedialog.askopenfilename(parent=dlg, title="Choisir la sauvegarde à restaurer",
                                           initialdir=str(self.base.dossier_sauvegardes),
                                           filetypes=[("Sauvegardes", "*.db")])
            if not f:
                return
            if not messagebox.askyesno(
                    "Restaurer une sauvegarde",
                    f"Remplacer TOUTES les données actuelles par la sauvegarde :\n{Path(f).name} ?\n\n"
                    "L'état actuel sera lui-même sauvegardé juste avant.", icon="warning",
                    default="no", parent=dlg):
                return
            self.base.restaurer(Path(f))
            if dlg is not None:
                dlg.fermer()
            self.courante = None
            self.charger()
            self.toast("Sauvegarde restaurée")

        def changer():
            nouveau = DialogueDossier(dlg or self.root, self.theme, self.base.dossier, None).montrer()
            if not nouveau or Path(nouveau) == self.base.dossier:
                return
            fichier = ecrire_dossier_base(Path(nouveau))
            messagebox.showinfo(APP_NOM, f"Nouveau dossier enregistré dans :\n{fichier}\n\n"
                                         "L'application va se fermer : relancez-la pour l'utiliser.",
                                parent=dlg)
            self.quitter()

        derniere = self.base.derniere_sauvegarde()
        valeurs = dict(asso=self.base.reglage("nom_asso", ""), seuil=self.seuil, noms=self.noms,
                       chemin=self.base.chemin,
                       info_sauvegarde=f"Dernière sauvegarde : {derniere}" if derniere
                       else "Aucune sauvegarde pour l'instant")

        def action(v):
            if not self._peut_ecrire():
                raise ErreurMetier("Écriture impossible : la base est en lecture seule.")
            self.base.definir_reglages(v)
            return True

        dlg = DialogueReglages(self.root, self.theme, valeurs, self.base.lecture_seule,
                               dict(ouvrir=ouvrir, sauvegarder=sauvegarder, restaurer=restaurer,
                                    changer=changer), action)
        if dlg.montrer():
            self.charger()
            self.toast("Réglages enregistrés")

    # ====================================================================== fin & erreurs
    def quitter(self) -> None:
        try:
            self.verrou.liberer()
            self.base.fermer()
        finally:
            self.root.destroy()

    def _erreur_inattendue(self, exc_type, exc, tb) -> None:
        log.error("Erreur : %s", "".join(traceback.format_exception(exc_type, exc, tb)))
        if isinstance(exc, ErreurMetier):
            messagebox.showwarning(APP_NOM, str(exc), parent=self.root)
        elif isinstance(exc, (sqlite3.OperationalError, OSError)):
            messagebox.showerror(
                APP_NOM, "Impossible d'accéder à la base de données.\n\n"
                         "Vérifiez que le dossier partagé est accessible (réseau, VPN), puis "
                         f"réessayez (F5).\n\nDétail : {exc}", parent=self.root)
        else:
            messagebox.showerror(
                APP_NOM, f"Une erreur inattendue s'est produite :\n{exc}\n\n"
                         "Le détail est enregistré dans le journal (journal.log).", parent=self.root)
