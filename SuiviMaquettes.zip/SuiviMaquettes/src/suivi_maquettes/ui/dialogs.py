"""Fenêtres modales : création, nouvelle configuration, vol, suppressions, réglages, démarrage."""

from __future__ import annotations

import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any, Callable

from .. import NB_PARAMETRES
from ..db import ErreurMetier, MaquetteResume, Trace, Vol
from ..formats import (ErreurSaisie, aujourd_hui_fr, format_date, format_duree, parse_date,
                       parse_duree)
from ..verrou import InfoVerrou
from .theme import P, Theme
from .widgets import BarrePotentiel, ZoneTexte, couleur_etat


class Dialogue(tk.Toplevel):
    """Base des modales : en-tête, corps, pied avec message d'erreur et boutons."""

    def __init__(self, parent: tk.Misc, theme: Theme, titre: str, sous_titre: str | None = None,
                 action: Callable[[Any], Any] | None = None):
        super().__init__(parent)
        self.withdraw()
        self.theme = theme
        self.action = action
        self.resultat: Any = None
        self._champs_erreur: list[ttk.Entry] = []
        px = theme.px
        self.title(titre)
        self.configure(background=P.SURFACE)
        self.resizable(False, False)
        maitre = parent.winfo_toplevel()
        if maitre.winfo_viewable():
            self.transient(maitre)

        cadre = ttk.Frame(self, style="Surface.TFrame", padding=(px(26), px(22), px(26), px(20)))
        cadre.pack(fill="both", expand=True)
        ttk.Label(cadre, text=titre, style="Surface.SousTitre.TLabel").pack(anchor="w")
        if sous_titre:
            ttk.Label(cadre, text=sous_titre, style="Surface.Gris.TLabel", wraplength=px(620),
                      justify="left").pack(anchor="w", pady=(px(3), 0))
        self.corps = ttk.Frame(cadre, style="Surface.TFrame")
        self.corps.pack(fill="both", expand=True, pady=(px(18), 0))
        ttk.Frame(cadre, style="Separateur.TFrame", height=1).pack(fill="x", pady=(px(6), 0))
        self.pied = ttk.Frame(cadre, style="Surface.TFrame")
        self.pied.pack(fill="x", pady=(px(16), 0))
        self.msg = ttk.Label(self.pied, text="", style="Surface.Erreur.TLabel",
                             wraplength=px(400), justify="left")
        self.msg.pack(side="left", fill="x", expand=True)

        self.bind("<Escape>", lambda e: self.annuler())
        self.protocol("WM_DELETE_WINDOW", self.annuler)

    # ------------------------------------------------------------------ construction
    def boutons(self, texte: str = "Enregistrer", style: str = "Accent.TButton",
                entree_valide: bool = True, texte_annuler: str = "Annuler") -> None:
        px = self.theme.px
        self.btn_valider = ttk.Button(self.pied, text=texte, style=style, command=self._valider)
        self.btn_valider.pack(side="right")
        self.btn_annuler = ttk.Button(self.pied, text=texte_annuler, command=self.annuler)
        self.btn_annuler.pack(side="right", padx=(0, px(10)))
        if entree_valide:
            self.bind("<Return>", self._touche_entree)
            self.bind("<KP_Enter>", self._touche_entree)

    def section(self, parent: ttk.Frame, ligne: int, texte: str, colonnes: int = 3,
                avec_info: bool = False) -> ttk.Label | None:
        px = self.theme.px
        bloc = ttk.Frame(parent, style="Surface.TFrame")
        bloc.grid(row=ligne, column=0, columnspan=colonnes, sticky="ew",
                  pady=(px(4) if ligne else 0, px(10)))
        ttk.Label(bloc, text=texte.upper(), style="Surface.Libelle.TLabel").pack(side="left")
        info = None
        if avec_info:
            info = ttk.Label(bloc, text="", style="Surface.Pale.TLabel")
            info.pack(side="right")
        ttk.Frame(bloc, style="Separateur.TFrame", height=1).pack(
            side="left", fill="x", expand=True, padx=(px(10), px(10) if avec_info else 0))
        return info

    def champ(self, parent: ttk.Frame, ligne: int, col: int, libelle: str, obligatoire=False,
              valeur: str = "", largeur: int = 24, aide: str | None = None,
              colspan: int = 1) -> ttk.Entry:
        px = self.theme.px
        cadre = ttk.Frame(parent, style="Surface.TFrame")
        cadre.grid(row=ligne, column=col, columnspan=colspan, sticky="new",
                   padx=(0 if col == 0 else px(14), 0), pady=(0, px(12)))
        cadre.columnconfigure(0, weight=1)
        lbl = ttk.Label(cadre, text=libelle + ("  *" if obligatoire else ""),
                        style="Surface.Libelle.TLabel")
        lbl.grid(row=0, column=0, sticky="w", pady=(0, px(4)))
        e = ttk.Entry(cadre, width=largeur)
        if valeur:
            e.insert(0, valeur)
        e.grid(row=1, column=0, sticky="ew")
        aide_lbl = ttk.Label(cadre, text=aide or "", style="Surface.Pale.TLabel")
        if aide:
            aide_lbl.grid(row=2, column=0, sticky="w", pady=(px(2), 0))
        e.libelle, e.aide, e.texte_libelle = lbl, aide_lbl, libelle  # type: ignore[attr-defined]
        e.bind("<Key>", lambda ev, w=e: self._retirer_erreur(w), add="+")
        return e

    def zone_commentaire(self, parent: ttk.Frame, ligne: int, colspan: int = 3,
                         libelle: str = "Commentaire", hauteur: int = 3) -> ZoneTexte:
        px = self.theme.px
        ttk.Label(parent, text=libelle, style="Surface.Libelle.TLabel").grid(
            row=ligne, column=0, columnspan=colspan, sticky="w", pady=(0, px(4)))
        z = ZoneTexte(parent, self.theme, hauteur=hauteur)
        z.grid(row=ligne + 1, column=0, columnspan=colspan, sticky="ew", pady=(0, px(6)))
        return z

    def grille(self, parent: ttk.Frame, colonnes: int = 3) -> None:
        for c in range(colonnes):
            parent.columnconfigure(c, weight=1, uniform="col")

    # ------------------------------------------------------------------ erreurs
    def erreur(self, texte: str, *champs: ttk.Entry) -> None:
        self.msg.configure(text=f"⚠  {texte}")
        for c in champs:
            c.configure(style="Erreur.TEntry")
            self._champs_erreur.append(c)
        if champs:
            champs[0].focus_set()
            champs[0].select_range(0, "end")
        self.bell()

    def _retirer_erreur(self, champ: ttk.Entry) -> None:
        if champ in self._champs_erreur:
            self._champs_erreur.remove(champ)
            champ.configure(style=self.style_normal(champ))
            if not self._champs_erreur:
                self.msg.configure(text="")

    def style_normal(self, _champ: ttk.Entry) -> str:
        return "TEntry"

    def obligatoires(self, *champs: ttk.Entry) -> bool:
        vides = [c for c in champs if not c.get().strip()]
        if vides:
            noms = ", ".join(f"« {c.texte_libelle} »" for c in vides)  # type: ignore[attr-defined]
            self.erreur(f"Champ obligatoire : {noms}." if len(vides) == 1
                        else f"Champs obligatoires : {noms}.", *vides)
            return False
        return True

    def lire_date(self, champ: ttk.Entry) -> str | None:
        try:
            return parse_date(champ.get())
        except ErreurSaisie as e:
            self.erreur(str(e), champ)
            return None

    # ------------------------------------------------------------------ cycle de vie
    def _touche_entree(self, e) -> None:
        if isinstance(e.widget, tk.Text):
            return
        if str(self.btn_valider.cget("state")) != "disabled":
            self._valider()

    def _valider(self) -> None:
        self._champs_erreur.clear()
        self.msg.configure(text="")
        donnees = self.collecter()
        if donnees is None:
            return
        if self.action is not None:
            try:
                self.resultat = self.action(donnees)
            except ErreurMetier as e:
                self.erreur(str(e))
                return
        else:
            self.resultat = donnees
        self.fermer()

    def collecter(self) -> Any:
        return True

    def montrer(self, focus: tk.Widget | None = None) -> Any:
        self.update_idletasks()
        l, h = self.winfo_reqwidth(), self.winfo_reqheight()
        maitre = self.master.winfo_toplevel()
        if maitre.winfo_viewable():
            x = maitre.winfo_rootx() + (maitre.winfo_width() - l) // 2
            y = maitre.winfo_rooty() + (maitre.winfo_height() - h) // 3
        else:
            x = (self.winfo_screenwidth() - l) // 2
            y = (self.winfo_screenheight() - h) // 3
        x = max(0, min(x, self.winfo_screenwidth() - l))
        y = max(0, min(y, self.winfo_screenheight() - h - 40))
        self.geometry(f"+{x}+{y}")
        self.deiconify()
        self.lift()
        try:
            self.grab_set()
        except tk.TclError:
            pass
        (focus or self).focus_force()
        self.wait_window()
        return self.resultat

    def annuler(self) -> None:
        self.resultat = None
        self.fermer()

    def fermer(self) -> None:
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


# ============================================================================ maquette


class DialogueMaquette(Dialogue):
    def __init__(self, parent, theme: Theme, noms: list[str], action):
        super().__init__(parent, theme, "Nouvelle maquette",
                         "Identification, configuration initiale et traçabilité. "
                         "Les champs marqués d'un astérisque sont obligatoires.", action)
        g = self.corps
        self.grille(g)
        self.section(g, 0, "Identification")
        self.e_num = self.champ(g, 1, 0, "N° de série", True)
        self.e_heures = self.champ(g, 1, 1, "Heures allouées", True,
                                   aide="Exemples : 50   ·   50h   ·   12h30")
        self.section(g, 2, "Configuration initiale")
        self.e_params = [self.champ(g, 3 + i // 3, i % 3, noms[i]) for i in range(NB_PARAMETRES)]
        self.section(g, 6, "Traçabilité")
        self.e_auteur = self.champ(g, 7, 0, "Auteur", True)
        self.e_date = self.champ(g, 7, 1, "Date", True, aujourd_hui_fr(), aide="JJ/MM/AAAA")
        self.e_type = self.champ(g, 7, 2, "Type", valeur="Configuration initiale")
        self.e_demandeur = self.champ(g, 8, 0, "Demandeur")
        self.e_objet = self.champ(g, 8, 1, "Objet", colspan=2)
        self.e_comm = self.zone_commentaire(g, 9)
        self.boutons("Créer la maquette")

    def collecter(self):
        if not self.obligatoires(self.e_num, self.e_heures, self.e_auteur, self.e_date):
            return None
        try:
            alloue = parse_duree(self.e_heures.get())
        except ErreurSaisie as e:
            self.erreur(str(e), self.e_heures)
            return None
        date = self.lire_date(self.e_date)
        if date is None:
            return None
        return dict(
            numero=self.e_num.get().strip(), alloue=alloue,
            parametres=[e.get() for e in self.e_params],
            trace=Trace(auteur=self.e_auteur.get(), date_effet=date, type=self.e_type.get(),
                        demandeur=self.e_demandeur.get(), objet=self.e_objet.get(),
                        commentaire=self.e_comm.valeur()),
        )

    def montrer(self, focus=None):
        return super().montrer(self.e_num)


# ============================================================================ configuration


class DialogueConfiguration(Dialogue):
    def __init__(self, parent, theme: Theme, noms: list[str], maquette: MaquetteResume, action):
        super().__init__(
            parent, theme, "Nouvelle configuration",
            f"Maquette {maquette.numero_serie}  ·  version actuelle v{maquette.version}  →  "
            f"nouvelle version v{maquette.version + 1}.  Modifiez un ou plusieurs paramètres ; "
            "l'ancienne configuration reste consultable dans l'historique.", action)
        self.actuels = list(maquette.parametres)
        g = self.corps
        self.grille(g)
        self.compteur = self.section(g, 0, "Paramètres", avec_info=True)
        self.e_params: list[ttk.Entry] = []
        for i in range(NB_PARAMETRES):
            e = self.champ(g, 1 + i // 3, i % 3, noms[i], valeur=self.actuels[i])
            e.bind("<KeyRelease>", lambda ev: self._actualiser(), add="+")
            e.bind("<<Paste>>", lambda ev: self.after_idle(self._actualiser), add="+")
            e.bind("<<Cut>>", lambda ev: self.after_idle(self._actualiser), add="+")
            self.e_params.append(e)
        self.section(g, 4, "Traçabilité du changement")
        self.e_auteur = self.champ(g, 5, 0, "Auteur", True)
        self.e_date = self.champ(g, 5, 1, "Date", True, aujourd_hui_fr(), aide="JJ/MM/AAAA")
        self.e_type = self.champ(g, 5, 2, "Type", True)
        self.e_demandeur = self.champ(g, 6, 0, "Demandeur", True)
        self.e_objet = self.champ(g, 6, 1, "Objet", True, colspan=2)
        self.e_comm = self.zone_commentaire(g, 7)
        self.boutons("Enregistrer la configuration")
        self._actualiser()

    def _modifies(self) -> list[int]:
        return [i for i, e in enumerate(self.e_params) if e.get().strip() != self.actuels[i]]

    def style_normal(self, champ):
        if champ in self.e_params and self.e_params.index(champ) in self._modifies():
            return "Modifie.TEntry"
        return "TEntry"

    def _actualiser(self) -> None:
        modifies = set(self._modifies())
        for i, e in enumerate(self.e_params):
            if e in self._champs_erreur:
                continue
            if i in modifies:
                e.configure(style="Modifie.TEntry")
                e.libelle.configure(text=f"{e.texte_libelle}   ● modifié", style="Surface.Modifie.TLabel")
                avant = self.actuels[i] or "(vide)"
                e.aide.configure(text=f"Avant : {avant}")
                e.aide.grid(row=2, column=0, sticky="w", pady=(self.theme.px(2), 0))
            else:
                e.configure(style="TEntry")
                e.libelle.configure(text=e.texte_libelle, style="Surface.Libelle.TLabel")
                e.aide.grid_remove()
        n = len(modifies)
        self.compteur.configure(
            text="Aucun paramètre modifié" if n == 0 else
            f"{n} paramètre{'s' if n > 1 else ''} modifié{'s' if n > 1 else ''}",
            style="Surface.Pale.TLabel" if n == 0 else "Surface.Modifie.TLabel")

    def collecter(self):
        if not self._modifies():
            self.erreur("Modifiez au moins un paramètre pour créer une nouvelle configuration.")
            self.e_params[0].focus_set()
            return None
        if not self.obligatoires(self.e_auteur, self.e_date, self.e_type, self.e_demandeur,
                                 self.e_objet):
            return None
        date = self.lire_date(self.e_date)
        if date is None:
            return None
        return dict(
            parametres=[e.get() for e in self.e_params],
            trace=Trace(auteur=self.e_auteur.get(), date_effet=date, type=self.e_type.get(),
                        demandeur=self.e_demandeur.get(), objet=self.e_objet.get(),
                        commentaire=self.e_comm.valeur()),
        )

    def montrer(self, focus=None):
        return super().montrer(self.e_params[0])


# ============================================================================ vol


class DialogueVol(Dialogue):
    def __init__(self, parent, theme: Theme, maquette: MaquetteResume, seuil: int, action):
        super().__init__(parent, theme, "Enregistrer un vol",
                         f"Maquette {maquette.numero_serie}  ·  temps restant : "
                         f"{format_duree(maquette.restant)} sur {format_duree(maquette.alloue)}.",
                         action)
        self.maquette, self.seuil = maquette, seuil
        px = theme.px
        style = ttk.Style(self)
        for nom, couleur in (("OK", P.OK), ("Alerte", P.ALERTE), ("Danger", P.DANGER)):
            style.configure(f"Apercu{nom}.TLabel", background=P.SURFACE_2, foreground=couleur,
                            font=theme.f_chiffre)
        g = self.corps
        self.grille(g, 2)
        self.e_date = self.champ(g, 0, 0, "Date du vol", True, aujourd_hui_fr(), aide="JJ/MM/AAAA")
        self.e_duree = self.champ(g, 0, 1, "Durée du vol", True,
                                  aide="Exemples : 1h30   ·   1:30   ·   1,5   ·   45 min")
        self.e_equipe = self.champ(g, 1, 0, "Équipe responsable", True, colspan=2)
        self.e_comm = self.zone_commentaire(g, 2, colspan=2)

        tuile = ttk.Frame(g, style="Tuile.TFrame", padding=(px(16), px(12)))
        tuile.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(px(8), 0))
        tuile.columnconfigure(1, weight=1)
        ttk.Label(tuile, text="RESTANT APRÈS CE VOL", style="Surface2.Libelle.TLabel").grid(
            row=0, column=0, sticky="w")
        self.l_apres = ttk.Label(tuile, text="", style="Surface2.Chiffre.TLabel")
        self.l_apres.grid(row=1, column=0, sticky="w", padx=(0, px(18)))
        self.barre = BarrePotentiel(tuile, theme, hauteur=10)
        self.barre.configure(style="Surface2.TLabel")
        self.barre.grid(row=1, column=1, sticky="ew")
        self.l_info = ttk.Label(tuile, text="", style="Surface2.Gris.TLabel")
        self.l_info.grid(row=2, column=0, columnspan=2, sticky="w", pady=(px(4), 0))
        self.e_duree.bind("<KeyRelease>", lambda e: self._apercu(), add="+")
        self.boutons("Enregistrer le vol")
        self._apercu()

    def _apercu(self) -> None:
        m = self.maquette
        try:
            d = parse_duree(self.e_duree.get())
        except ErreurSaisie:
            d = 0
        apres = m.restant - d
        couleur = couleur_etat(apres, m.alloue, self.seuil)
        style = {P.OK: "OK", P.ALERTE: "Alerte", P.DANGER: "Danger"}[couleur]
        self.l_apres.configure(text=format_duree(apres), style=f"Apercu{style}.TLabel")
        self.barre.definir(max(0.0, apres / m.alloue), couleur)
        if d == 0:
            self.l_info.configure(text="Saisissez la durée pour voir le temps restant.")
        elif apres < 0:
            self.l_info.configure(text=f"⚠  Dépassement de {format_duree(-apres)} du potentiel alloué.")
        else:
            self.l_info.configure(text=f"Ce vol consomme {format_duree(d)} "
                                       f"({d * 100 / m.alloue:.1f} % du potentiel).")

    def collecter(self):
        if not self.obligatoires(self.e_date, self.e_duree, self.e_equipe):
            return None
        date = self.lire_date(self.e_date)
        if date is None:
            return None
        try:
            duree = parse_duree(self.e_duree.get())
        except ErreurSaisie as e:
            self.erreur(str(e), self.e_duree)
            return None
        if duree > self.maquette.restant:
            if not messagebox.askyesno(
                    "Dépassement du potentiel",
                    f"Ce vol ({format_duree(duree)}) dépasse le temps restant de la maquette "
                    f"({format_duree(self.maquette.restant)}).\n\n"
                    f"Le temps restant passera à {format_duree(self.maquette.restant - duree)}.\n\n"
                    "Enregistrer le vol quand même ?", icon="warning", default="no", parent=self):
                return None
        return dict(date=date, duree=duree, equipe=self.e_equipe.get(),
                    commentaire=self.e_comm.valeur())

    def montrer(self, focus=None):
        return super().montrer(self.e_duree)


# ============================================================================ suppressions


class DialogueSuppressionMaquette(Dialogue):
    def __init__(self, parent, theme: Theme, maquette: MaquetteResume, nb_conf: int, nb_vols: int,
                 action):
        super().__init__(parent, theme, "Supprimer définitivement la maquette", None, action)
        px = theme.px
        self.numero = maquette.numero_serie
        g = self.corps
        bandeau = ttk.Frame(g, style="BandeauDanger.TFrame", padding=(px(14), px(10)))
        bandeau.pack(fill="x")
        ttk.Label(bandeau, text="⚠  Cette action est définitive.", style="BandeauDangerSemi.TLabel"
                  ).pack(anchor="w")
        ttk.Label(bandeau, style="BandeauDanger.TLabel", wraplength=px(480), justify="left",
                  text=f"Seront supprimés : la maquette {maquette.numero_serie}, ses {nb_conf} "
                       f"configuration{'s' if nb_conf > 1 else ''} et ses {nb_vols} "
                       f"vol{'s' if nb_vols > 1 else ''} ({format_duree(maquette.consomme)} de vol)."
                  ).pack(anchor="w", pady=(px(4), 0))
        ttk.Label(g, style="Surface.Gris.TLabel", wraplength=px(500), justify="left",
                  text="Une sauvegarde complète de la base est faite automatiquement juste avant "
                       "la suppression (dossier « sauvegardes »).").pack(anchor="w", pady=(px(14), px(14)))
        ttk.Label(g, text=f"Pour confirmer, saisissez le numéro de série « {self.numero} » :",
                  style="Surface.Semi.TLabel").pack(anchor="w", pady=(0, px(6)))
        self.e_conf = ttk.Entry(g, width=40)
        self.e_conf.pack(fill="x")
        self.e_conf.bind("<KeyRelease>", lambda e: self._verifier())
        self.boutons("Supprimer définitivement", "Danger.TButton", entree_valide=False)
        self._verifier()

    def _verifier(self) -> None:
        ok = self.e_conf.get().strip().casefold() == self.numero.casefold()
        self.btn_valider.configure(state="normal" if ok else "disabled")

    def montrer(self, focus=None):
        return super().montrer(self.e_conf)


class DialogueSuppressionVol(Dialogue):
    def __init__(self, parent, theme: Theme, numero: str, vol: Vol, action):
        super().__init__(parent, theme, "Supprimer définitivement ce vol", None, action)
        px = theme.px
        g = self.corps
        tuile = ttk.Frame(g, style="Tuile.TFrame", padding=(px(16), px(12)))
        tuile.pack(fill="x")
        for i, (cle, val) in enumerate((("Maquette", numero), ("Date", format_date(vol.date_vol)),
                                        ("Durée", format_duree(vol.duree)), ("Équipe", vol.equipe),
                                        ("Commentaire", vol.commentaire or "—"))):
            ttk.Label(tuile, text=cle, style="Surface2.Gris.TLabel").grid(
                row=i, column=0, sticky="nw", padx=(0, px(18)), pady=px(2))
            ttk.Label(tuile, text=val, style="Surface2.Semi.TLabel" if i < 4 else "Surface2.TLabel",
                      wraplength=px(380), justify="left").grid(row=i, column=1, sticky="w", pady=px(2))
        ttk.Label(g, style="Surface.Gris.TLabel", wraplength=px(480), justify="left",
                  text=f"Les {format_duree(vol.duree)} de ce vol seront recréditées sur la maquette. "
                       "Une sauvegarde de la base est faite automatiquement avant la suppression."
                  ).pack(anchor="w", pady=(px(14), px(10)))
        self.var = tk.BooleanVar(value=False)
        ttk.Checkbutton(g, text="Je confirme que ce vol a été saisi par erreur", variable=self.var,
                        command=self._verifier).pack(anchor="w")
        self.boutons("Supprimer définitivement", "Danger.TButton", entree_valide=False)
        self._verifier()

    def _verifier(self) -> None:
        self.btn_valider.configure(state="normal" if self.var.get() else "disabled")

    def montrer(self, focus=None):
        return super().montrer(self.btn_annuler)


# ============================================================================ réglages


class DialogueReglages(Dialogue):
    def __init__(self, parent, theme: Theme, valeurs: dict[str, Any], lecture_seule: bool,
                 actions: dict[str, Callable[[], None]], action):
        super().__init__(parent, theme, "Réglages",
                         "Ces réglages sont enregistrés dans la base partagée : "
                         "ils s'appliquent à tous les utilisateurs.", action)
        px = theme.px
        g = self.corps
        self.grille(g)
        self.section(g, 0, "Général")
        self.e_asso = self.champ(g, 1, 0, "Nom affiché dans l'en-tête", valeur=valeurs["asso"],
                                 colspan=2, aide="Par exemple le nom de l'association")
        self.e_seuil = self.champ(g, 1, 2, "Seuil d'alerte (%)", valeur=str(valeurs["seuil"]),
                                  aide="Orange sous ce pourcentage restant")
        self.section(g, 2, "Noms des paramètres de configuration")
        self.e_noms = [self.champ(g, 3 + i // 3, i % 3, f"Paramètre {i + 1}", valeur=valeurs["noms"][i])
                       for i in range(NB_PARAMETRES)]
        self.section(g, 6, "Base de données")
        bloc = ttk.Frame(g, style="Tuile.TFrame", padding=(px(14), px(10)))
        bloc.grid(row=7, column=0, columnspan=3, sticky="ew")
        bloc.columnconfigure(0, weight=1)
        ttk.Label(bloc, text=str(valeurs["chemin"]), style="Surface2.Semi.TLabel", wraplength=px(600)
                  ).grid(row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(bloc, text=valeurs["info_sauvegarde"], style="Surface2.Gris.TLabel").grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(px(2), px(8)))
        boutons = ttk.Frame(bloc, style="Surface2.TFrame")
        boutons.grid(row=2, column=0, columnspan=4, sticky="w")
        for texte, cle, ecriture in (("Ouvrir le dossier", "ouvrir", False),
                                     ("Sauvegarder maintenant", "sauvegarder", True),
                                     ("Restaurer une sauvegarde…", "restaurer", True),
                                     ("Changer de dossier…", "changer", False)):
            b = ttk.Button(boutons, text=texte, command=actions[cle])
            b.pack(side="left", padx=(0, px(8)))
            if ecriture and lecture_seule:
                b.configure(state="disabled")
        self.boutons("Enregistrer les réglages")
        if lecture_seule:
            for e in (self.e_asso, self.e_seuil, *self.e_noms):
                e.configure(state="disabled")
            self.btn_valider.configure(state="disabled")
            self.msg.configure(text="Lecture seule : réglages non modifiables.", style="Surface.Gris.TLabel")

    def collecter(self):
        try:
            seuil = int(self.e_seuil.get().strip().rstrip("%").strip())
            if not 0 <= seuil <= 100:
                raise ValueError
        except ValueError:
            self.erreur("Le seuil doit être un nombre entier entre 0 et 100.", self.e_seuil)
            return None
        noms = [e.get().strip() for e in self.e_noms]
        vides = [e for e, n in zip(self.e_noms, noms) if not n]
        if vides:
            self.erreur("Chaque paramètre doit avoir un nom.", *vides)
            return None
        if len({n.casefold() for n in noms}) < len(noms):
            self.erreur("Deux paramètres portent le même nom.")
            return None
        valeurs = {"nom_asso": self.e_asso.get().strip(), "seuil_alerte": str(seuil)}
        valeurs.update({f"nom_p{i + 1}": n for i, n in enumerate(noms)})
        return valeurs


# ============================================================================ démarrage


class DialogueDossier(Dialogue):
    """Choix du dossier partagé contenant (ou qui contiendra) la base."""

    def __init__(self, parent, theme: Theme, actuel: Path | None, probleme: str | None):
        super().__init__(parent, theme, "Dossier de la base de données",
                         "Indiquez le dossier partagé où se trouve la base (ou où elle sera créée). "
                         "Tous les utilisateurs doivent pointer vers le même dossier.")
        px = theme.px
        g = self.corps
        if probleme:
            bandeau = ttk.Frame(g, style="BandeauAlerte.TFrame", padding=(px(14), px(10)))
            bandeau.pack(fill="x", pady=(0, px(14)))
            ttk.Label(bandeau, text=probleme, style="BandeauAlerte.TLabel", wraplength=px(560),
                      justify="left").pack(anchor="w")
        ttk.Label(g, text="Chemin du dossier", style="Surface.Libelle.TLabel").pack(anchor="w",
                                                                                    pady=(0, px(4)))
        ligne = ttk.Frame(g, style="Surface.TFrame")
        ligne.pack(fill="x")
        self.e_chemin = ttk.Entry(ligne, width=60)
        self.e_chemin.pack(side="left", fill="x", expand=True)
        if actuel:
            self.e_chemin.insert(0, str(actuel))
        ttk.Button(ligne, text="Parcourir…", command=self._parcourir).pack(side="left", padx=(px(8), 0))
        ttk.Label(g, text="Exemple : \\\\serveur\\partage\\Maquettes   (vous pouvez coller le chemin "
                          "depuis la barre d'adresse de l'Explorateur)", style="Surface.Pale.TLabel"
                  ).pack(anchor="w", pady=(px(4), 0))
        self.boutons("Continuer", texte_annuler="Quitter")

    def _parcourir(self) -> None:
        d = filedialog.askdirectory(parent=self, title="Dossier de la base de données",
                                    initialdir=self.e_chemin.get() or None, mustexist=True)
        if d:
            self.e_chemin.delete(0, "end")
            self.e_chemin.insert(0, str(Path(d)))

    def collecter(self):
        texte = self.e_chemin.get().strip().strip('"')
        if not texte:
            self.erreur("Indiquez un dossier.", self.e_chemin)
            return None
        chemin = Path(texte)
        try:
            ok = chemin.is_dir()
        except OSError:
            ok = False
        if not ok:
            self.erreur("Ce dossier est introuvable ou inaccessible (vérifiez le réseau ou le VPN).",
                        self.e_chemin)
            return None
        return chemin

    def montrer(self, focus=None):
        return super().montrer(self.e_chemin)


class DialogueVerrou(Dialogue):
    """La base est déjà ouverte en écriture par quelqu'un d'autre."""

    def __init__(self, parent, theme: Theme, info: InfoVerrou):
        super().__init__(parent, theme, "Base déjà en cours d'utilisation")
        px = theme.px
        g = self.corps
        depuis = time.strftime("%d/%m/%Y à %H:%M", time.localtime(info.depuis)) if info.depuis else "?"
        tuile = ttk.Frame(g, style="Tuile.TFrame", padding=(px(16), px(12)))
        tuile.pack(fill="x")
        for i, (cle, val) in enumerate((("Utilisateur", info.utilisateur), ("Poste", info.poste),
                                        ("Ouverte le", depuis))):
            ttk.Label(tuile, text=cle, style="Surface2.Gris.TLabel").grid(
                row=i, column=0, sticky="w", padx=(0, px(18)), pady=px(2))
            ttk.Label(tuile, text=val, style="Surface2.Semi.TLabel").grid(row=i, column=1, sticky="w")
        minutes = int(info.inactif_depuis_s // 60)
        duree = (f"{minutes} min" if minutes < 120 else f"{minutes // 60} h" if minutes < 2880
                 else f"{minutes // 1440} jours")
        if info.perime:
            texte = (f"Aucune activité de cette session depuis {duree} : elle a probablement été "
                     "interrompue (fermeture brutale, coupure réseau, PC en veille). "
                     "Vous pouvez prendre la main sans risque.")
            style = "BandeauAlerte"
        else:
            texte = ("Une seule personne peut modifier les données à la fois. Vous pouvez consulter "
                     "les données en lecture seule, ou prendre la main : l'autre session passera "
                     "alors automatiquement en lecture seule (rien de ce qu'elle a déjà enregistré "
                     "n'est perdu).")
            style = "BandeauInfo"
        bandeau = ttk.Frame(g, style=f"{style}.TFrame", padding=(px(14), px(10)))
        bandeau.pack(fill="x", pady=(px(14), 0))
        ttk.Label(bandeau, text=texte, style=f"{style}.TLabel", wraplength=px(500),
                  justify="left").pack(anchor="w")

        ttk.Button(self.pied, text="Ouvrir en lecture seule", style="Accent.TButton",
                   command=lambda: self._choisir("lecture")).pack(side="right")
        ttk.Button(self.pied, text="Prendre la main",
                   style="TButton" if info.perime else "DangerLeger.TButton",
                   command=lambda: self._choisir("forcer")).pack(side="right", padx=(0, px(8)))
        ttk.Button(self.pied, text="Quitter", command=self.annuler).pack(side="right", padx=(0, px(8)))
        self.msg.pack_forget()

    def _choisir(self, choix: str) -> None:
        self.resultat = choix
        self.fermer()
