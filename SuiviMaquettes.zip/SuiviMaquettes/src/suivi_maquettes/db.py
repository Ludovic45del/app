"""Accès aux données (SQLite).

La base est un fichier unique « suivi_maquettes.db » posé dans le dossier
partagé. Réglages adaptés à un partage réseau Windows (SMB) :
journal « DELETE » (le mode WAL ne fonctionne pas sur un partage réseau),
synchronous=FULL, clés étrangères actives, une seule session en écriture
à la fois (garantie par le verrou applicatif, voir verrou.py).
"""

from __future__ import annotations

import datetime as dt
import logging
import shutil
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

from . import NB_PARAMETRES
from .formats import maintenant_iso

log = logging.getLogger(__name__)

NOM_FICHIER_DB = "suivi_maquettes.db"
DOSSIER_SAUVEGARDES = "sauvegardes"
NB_SAUVEGARDES_CONSERVEES = 60
VERSION_SCHEMA = 1

COLONNES_P = [f"p{i}" for i in range(1, NB_PARAMETRES + 1)]

_SCHEMA = f"""
CREATE TABLE IF NOT EXISTS reglage (
    cle    TEXT PRIMARY KEY,
    valeur TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS maquette (
    id                   INTEGER PRIMARY KEY,
    numero_serie         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    heures_allouees_min  INTEGER NOT NULL CHECK (heures_allouees_min > 0),
    cree_le              TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS configuration (
    id           INTEGER PRIMARY KEY,
    maquette_id  INTEGER NOT NULL REFERENCES maquette(id) ON DELETE CASCADE,
    version      INTEGER NOT NULL,
    {", ".join(f"{c} TEXT NOT NULL DEFAULT ''" for c in COLONNES_P)},
    date_effet   TEXT NOT NULL,
    auteur       TEXT NOT NULL,
    type         TEXT NOT NULL DEFAULT '',
    demandeur    TEXT NOT NULL DEFAULT '',
    objet        TEXT NOT NULL DEFAULT '',
    commentaire  TEXT NOT NULL DEFAULT '',
    saisi_le     TEXT NOT NULL,
    UNIQUE (maquette_id, version)
);

CREATE TABLE IF NOT EXISTS vol (
    id           INTEGER PRIMARY KEY,
    maquette_id  INTEGER NOT NULL REFERENCES maquette(id) ON DELETE CASCADE,
    date_vol     TEXT NOT NULL,
    duree_min    INTEGER NOT NULL CHECK (duree_min > 0),
    equipe       TEXT NOT NULL,
    commentaire  TEXT NOT NULL DEFAULT '',
    saisi_le     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_vol_maquette ON vol (maquette_id, date_vol);
"""


class ErreurMetier(Exception):
    """Règle de gestion non respectée ; message affichable tel quel."""


@dataclass(slots=True)
class Trace:
    auteur: str
    date_effet: str            # ISO AAAA-MM-JJ
    type: str = ""
    demandeur: str = ""
    objet: str = ""
    commentaire: str = ""


@dataclass(slots=True)
class MaquetteResume:
    id: int
    numero_serie: str
    alloue: int                # minutes
    consomme: int              # minutes
    version: int
    date_config: str
    dernier_vol: str | None
    nb_vols: int
    parametres: list[str] = field(default_factory=list)

    @property
    def restant(self) -> int:
        return self.alloue - self.consomme


@dataclass(slots=True)
class Configuration:
    id: int
    version: int
    parametres: list[str]
    date_effet: str
    auteur: str
    type: str
    demandeur: str
    objet: str
    commentaire: str
    saisi_le: str


@dataclass(slots=True)
class Vol:
    id: int
    date_vol: str
    duree: int
    equipe: str
    commentaire: str
    saisi_le: str


def _nettoyer(valeur: str | None) -> str:
    return (valeur or "").strip()


class Base:
    def __init__(self, dossier: Path, lecture_seule: bool = False):
        self.dossier = Path(dossier)
        self.chemin = self.dossier / NOM_FICHIER_DB
        self.lecture_seule = lecture_seule
        self.cx = self._ouvrir()

    # ------------------------------------------------------------------ connexion
    def _ouvrir(self) -> sqlite3.Connection:
        if self.lecture_seule and not self.chemin.exists():
            raise ErreurMetier("La base de données n'existe pas encore dans ce dossier.")
        cx = sqlite3.connect(self.chemin, timeout=15, check_same_thread=False)
        cx.row_factory = sqlite3.Row
        cx.execute("PRAGMA foreign_keys = ON")
        cx.execute("PRAGMA busy_timeout = 15000")
        if self.lecture_seule:
            cx.execute("PRAGMA query_only = ON")   # aucune écriture possible, même par erreur
        else:
            cx.execute("PRAGMA journal_mode = DELETE")
            cx.execute("PRAGMA synchronous = FULL")
            self._migrer(cx)
        return cx

    def _migrer(self, cx: sqlite3.Connection) -> None:
        version = cx.execute("PRAGMA user_version").fetchone()[0]
        if version > VERSION_SCHEMA:
            raise ErreurMetier(
                "Cette base a été créée par une version plus récente de l'application. "
                "Utilisez la dernière version de l'exécutable."
            )
        if version < VERSION_SCHEMA:
            with cx:
                cx.executescript(_SCHEMA)
                cx.execute(f"PRAGMA user_version = {VERSION_SCHEMA}")
            log.info("Schéma initialisé (version %s)", VERSION_SCHEMA)

    def passer_en_lecture_seule(self) -> None:
        self.fermer()
        self.lecture_seule = True
        self.cx = self._ouvrir()

    def fermer(self) -> None:
        try:
            self.cx.close()
        except Exception:  # pragma: no cover
            pass

    def _ecriture(self) -> None:
        if self.lecture_seule:
            raise ErreurMetier("L'application est ouverte en lecture seule.")

    # ------------------------------------------------------------------ réglages
    def reglage(self, cle: str, defaut: str = "") -> str:
        row = self.cx.execute("SELECT valeur FROM reglage WHERE cle = ?", (cle,)).fetchone()
        return row[0] if row else defaut

    def definir_reglages(self, valeurs: dict[str, str]) -> None:
        self._ecriture()
        with self.cx:
            self.cx.executemany(
                "INSERT INTO reglage (cle, valeur) VALUES (?, ?) "
                "ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur",
                list(valeurs.items()),
            )

    def noms_parametres(self) -> list[str]:
        rows = dict(self.cx.execute(
            "SELECT cle, valeur FROM reglage WHERE cle LIKE 'nom_p%'").fetchall())
        return [rows.get(f"nom_p{i}") or f"Paramètre {i}" for i in range(1, NB_PARAMETRES + 1)]

    def seuil_alerte(self) -> int:
        try:
            return max(0, min(100, int(self.reglage("seuil_alerte", "20"))))
        except ValueError:
            return 20

    # ------------------------------------------------------------------ lecture
    def liste_maquettes(self) -> list[MaquetteResume]:
        cols = ", ".join(f"c.{c}" for c in COLONNES_P)
        sql = f"""
            SELECT m.id, m.numero_serie, m.heures_allouees_min,
                   COALESCE(v.total, 0) AS consomme, COALESCE(v.nb, 0) AS nb_vols, v.dernier,
                   c.version, c.date_effet, {cols}
            FROM maquette m
            JOIN configuration c ON c.maquette_id = m.id
             AND c.version = (SELECT MAX(version) FROM configuration WHERE maquette_id = m.id)
            LEFT JOIN (SELECT maquette_id, SUM(duree_min) AS total, COUNT(*) AS nb,
                              MAX(date_vol) AS dernier
                       FROM vol GROUP BY maquette_id) v ON v.maquette_id = m.id
            ORDER BY m.numero_serie COLLATE NOCASE
        """
        return [
            MaquetteResume(
                id=r["id"], numero_serie=r["numero_serie"], alloue=r["heures_allouees_min"],
                consomme=r["consomme"], version=r["version"], date_config=r["date_effet"],
                dernier_vol=r["dernier"], nb_vols=r["nb_vols"],
                parametres=[r[c] for c in COLONNES_P],
            )
            for r in self.cx.execute(sql)
        ]

    def maquette(self, maquette_id: int) -> MaquetteResume | None:
        return next((m for m in self.liste_maquettes() if m.id == maquette_id), None)

    def configurations(self, maquette_id: int) -> list[Configuration]:
        """Historique complet, de la plus récente à la plus ancienne."""
        rows = self.cx.execute(
            "SELECT * FROM configuration WHERE maquette_id = ? ORDER BY version DESC",
            (maquette_id,),
        )
        return [
            Configuration(
                id=r["id"], version=r["version"], parametres=[r[c] for c in COLONNES_P],
                date_effet=r["date_effet"], auteur=r["auteur"], type=r["type"],
                demandeur=r["demandeur"], objet=r["objet"], commentaire=r["commentaire"],
                saisi_le=r["saisi_le"],
            )
            for r in rows
        ]

    def vols(self, maquette_id: int) -> list[Vol]:
        rows = self.cx.execute(
            "SELECT * FROM vol WHERE maquette_id = ? ORDER BY date_vol DESC, id DESC",
            (maquette_id,),
        )
        return [
            Vol(id=r["id"], date_vol=r["date_vol"], duree=r["duree_min"], equipe=r["equipe"],
                commentaire=r["commentaire"], saisi_le=r["saisi_le"])
            for r in rows
        ]

    def compter_dependances(self, maquette_id: int) -> tuple[int, int]:
        nb_c = self.cx.execute(
            "SELECT COUNT(*) FROM configuration WHERE maquette_id = ?", (maquette_id,)).fetchone()[0]
        nb_v = self.cx.execute(
            "SELECT COUNT(*) FROM vol WHERE maquette_id = ?", (maquette_id,)).fetchone()[0]
        return nb_c, nb_v

    # ------------------------------------------------------------------ écriture
    def creer_maquette(self, numero_serie: str, alloue_min: int,
                       parametres: list[str], trace: Trace) -> int:
        self._ecriture()
        numero = _nettoyer(numero_serie)
        if not numero:
            raise ErreurMetier("Le numéro de série est obligatoire.")
        if alloue_min <= 0:
            raise ErreurMetier("Les heures allouées doivent être supérieures à zéro.")
        if not _nettoyer(trace.auteur):
            raise ErreurMetier("L'auteur est obligatoire.")
        maintenant = maintenant_iso()
        try:
            with self.cx:
                cur = self.cx.execute(
                    "INSERT INTO maquette (numero_serie, heures_allouees_min, cree_le) VALUES (?, ?, ?)",
                    (numero, alloue_min, maintenant),
                )
                maquette_id = cur.lastrowid
                self._inserer_configuration(maquette_id, 1, parametres, trace, maintenant)
        except sqlite3.IntegrityError as e:
            if "numero_serie" in str(e):
                raise ErreurMetier(f"Le numéro de série « {numero} » existe déjà.") from None
            raise
        log.info("Maquette créée : %s", numero)
        return maquette_id

    def nouvelle_configuration(self, maquette_id: int, parametres: list[str], trace: Trace) -> int:
        self._ecriture()
        for nom, valeur in (("auteur", trace.auteur), ("type", trace.type),
                            ("demandeur", trace.demandeur), ("objet", trace.objet)):
            if not _nettoyer(valeur):
                raise ErreurMetier(f"Le champ « {nom} » est obligatoire.")
        with self.cx:
            actuelle = self.cx.execute(
                f"SELECT version, {', '.join(COLONNES_P)} FROM configuration "
                "WHERE maquette_id = ? ORDER BY version DESC LIMIT 1", (maquette_id,),
            ).fetchone()
            if actuelle is None:
                raise ErreurMetier("Maquette introuvable (elle a peut-être été supprimée).")
            nouveaux = [_nettoyer(p) for p in parametres]
            if nouveaux == [actuelle[c] for c in COLONNES_P]:
                raise ErreurMetier("Aucun paramètre n'a été modifié.")
            version = actuelle["version"] + 1
            self._inserer_configuration(maquette_id, version, nouveaux, trace, maintenant_iso())
        log.info("Configuration v%s enregistrée pour la maquette %s", version, maquette_id)
        return version

    def _inserer_configuration(self, maquette_id: int, version: int, parametres: list[str],
                               trace: Trace, saisi_le: str) -> None:
        if len(parametres) != NB_PARAMETRES:
            raise ValueError(f"{NB_PARAMETRES} paramètres attendus")
        self.cx.execute(
            f"INSERT INTO configuration (maquette_id, version, {', '.join(COLONNES_P)}, "
            "date_effet, auteur, type, demandeur, objet, commentaire, saisi_le) "
            f"VALUES (?, ?, {', '.join('?' * NB_PARAMETRES)}, ?, ?, ?, ?, ?, ?, ?)",
            (maquette_id, version, *[_nettoyer(p) for p in parametres],
             trace.date_effet, _nettoyer(trace.auteur), _nettoyer(trace.type),
             _nettoyer(trace.demandeur), _nettoyer(trace.objet),
             (trace.commentaire or "").strip(), saisi_le),
        )

    def ajouter_vol(self, maquette_id: int, date_vol: str, duree_min: int,
                    equipe: str, commentaire: str = "") -> int:
        self._ecriture()
        if duree_min <= 0:
            raise ErreurMetier("La durée doit être supérieure à zéro.")
        if not _nettoyer(equipe):
            raise ErreurMetier("L'équipe responsable est obligatoire.")
        with self.cx:
            cur = self.cx.execute(
                "INSERT INTO vol (maquette_id, date_vol, duree_min, equipe, commentaire, saisi_le) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (maquette_id, date_vol, duree_min, _nettoyer(equipe),
                 (commentaire or "").strip(), maintenant_iso()),
            )
        return cur.lastrowid

    def supprimer_vol(self, vol_id: int) -> None:
        self._ecriture()
        self.sauvegarder("avant-suppression-vol")
        with self.cx:
            self.cx.execute("DELETE FROM vol WHERE id = ?", (vol_id,))
        log.warning("Vol %s supprimé", vol_id)

    def supprimer_maquette(self, maquette_id: int) -> None:
        self._ecriture()
        self.sauvegarder("avant-suppression-maquette")
        with self.cx:
            self.cx.execute("DELETE FROM maquette WHERE id = ?", (maquette_id,))
        log.warning("Maquette %s supprimée", maquette_id)

    # ------------------------------------------------------------------ sauvegardes
    @property
    def dossier_sauvegardes(self) -> Path:
        return self.dossier / DOSSIER_SAUVEGARDES

    def sauvegarder(self, motif: str = "manuelle") -> Path:
        """Copie cohérente de la base (API de sauvegarde SQLite) + rotation."""
        self.dossier_sauvegardes.mkdir(exist_ok=True)
        horodatage = dt.datetime.now().strftime("%Y-%m-%d_%H%M%S")
        cible = self.dossier_sauvegardes / f"suivi_maquettes_{horodatage}_{motif}.db"
        local = sqlite3.connect(cible)
        try:
            self.cx.backup(local)
        finally:
            local.close()
        self._rotation()
        log.info("Sauvegarde : %s", cible.name)
        return cible

    def sauvegarde_quotidienne(self) -> Path | None:
        if self.lecture_seule:
            return None
        jour = dt.date.today().strftime("%Y-%m-%d")
        if any(self.dossier_sauvegardes.glob(f"suivi_maquettes_{jour}_*.db")):
            return None
        return self.sauvegarder("quotidienne")

    def derniere_sauvegarde(self) -> str | None:
        fichiers = sorted(self.dossier_sauvegardes.glob("suivi_maquettes_*.db"))
        return fichiers[-1].name if fichiers else None

    def _rotation(self) -> None:
        fichiers = sorted(self.dossier_sauvegardes.glob("suivi_maquettes_*.db"))
        for ancien in fichiers[:-NB_SAUVEGARDES_CONSERVEES]:
            try:
                ancien.unlink()
            except OSError:
                pass

    def restaurer(self, sauvegarde: Path) -> None:
        """Remplace la base par une sauvegarde (une sauvegarde de l'état actuel est faite avant)."""
        self._ecriture()
        self.sauvegarder("avant-restauration")
        self.fermer()
        shutil.copy2(sauvegarde, self.chemin)
        self.cx = self._ouvrir()
