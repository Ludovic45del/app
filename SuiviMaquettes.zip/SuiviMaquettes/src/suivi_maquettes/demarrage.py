"""Séquence de démarrage : dossier de la base, verrou, ouverture, fenêtre principale."""

from __future__ import annotations

import logging
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

from . import APP_ID, APP_NOM, VERSION
from .config import (configurer_journal, dossier_accessible, dossier_inscriptible, dossier_ressources,
                     ecrire_dossier_base, lire_dossier_base)
from .db import NOM_FICHIER_DB, Base, ErreurMetier
from .verrou import Verrou

log = logging.getLogger(__name__)


def _activer_dpi() -> None:
    """Texte net sur les écrans haute résolution de Windows 11 (sinon Windows étire l'image)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)      # par écran
        except (AttributeError, OSError):
            ctypes.windll.user32.SetProcessDPIAware()
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(f"Association.{APP_ID}")
    except Exception:  # pragma: no cover
        pass


def _icone(root: tk.Tk) -> None:
    ico = dossier_ressources() / "assets" / "app.ico"
    try:
        if sys.platform == "win32" and ico.exists():
            root.iconbitmap(default=str(ico))
        else:
            png = dossier_ressources() / "assets" / "logo_48.png"
            if png.exists():
                root.iconphoto(True, tk.PhotoImage(file=str(png)))
    except tk.TclError:
        pass


def _choisir_dossier(root: tk.Tk, theme) -> Path | None:
    from .ui.dialogs import DialogueDossier

    dossier = lire_dossier_base()
    probleme = None
    if dossier is None:
        probleme = ("Premier lancement : aucun dossier de base n'est encore configuré sur ce poste.")
    elif not dossier_accessible(dossier):
        probleme = (f"Le dossier configuré est inaccessible :\n{dossier}\n\n"
                    "Vérifiez que vous êtes connecté au réseau (ou au VPN), puis cliquez sur "
                    "« Continuer », ou choisissez un autre dossier.")
    else:
        return dossier

    while True:
        choix = DialogueDossier(root, theme, dossier, probleme).montrer()
        if choix is None:
            return None
        choix = Path(choix)
        if not (choix / NOM_FICHIER_DB).exists():
            if not messagebox.askyesno(
                    APP_NOM, f"Aucune base n'existe encore dans :\n{choix}\n\n"
                             "Créer une nouvelle base vide dans ce dossier ?\n\n"
                             "(Répondez « Non » si vos collègues utilisent déjà une base : "
                             "elle se trouve dans un autre dossier.)"):
                dossier, probleme = choix, None
                continue
        try:
            ecrire_dossier_base(choix)
        except OSError as e:
            log.warning("config.ini non écrit : %s", e)
        return choix


def lancer() -> int:
    _activer_dpi()
    fichier_journal = configurer_journal()
    log.info("Démarrage %s %s", APP_NOM, VERSION)

    root = tk.Tk(className=APP_ID)
    root.withdraw()
    _icone(root)

    from .ui.theme import Theme
    theme = Theme(root)

    dossier = _choisir_dossier(root, theme)
    if dossier is None:
        root.destroy()
        return 0

    lecture_seule = False
    if not dossier_inscriptible(dossier):
        if not messagebox.askyesno(APP_NOM, f"Vous n'avez pas les droits d'écriture sur :\n{dossier}\n\n"
                                            "Ouvrir les données en lecture seule ?"):
            root.destroy()
            return 0
        lecture_seule = True

    verrou = Verrou(dossier)
    if not lecture_seule:
        autre = verrou.acquerir()
        if autre is not None:
            from .ui.dialogs import DialogueVerrou
            choix = DialogueVerrou(root, theme, autre).montrer()
            if choix is None:
                root.destroy()
                return 0
            if choix == "forcer":
                verrou.acquerir(forcer=True)
            else:
                lecture_seule = True

    try:
        base = Base(dossier, lecture_seule=lecture_seule)
        base.sauvegarde_quotidienne()
    except ErreurMetier as e:
        verrou.liberer()
        messagebox.showerror(APP_NOM, str(e))
        root.destroy()
        return 1
    except Exception as e:  # base corrompue, réseau…
        log.exception("Ouverture de la base impossible")
        verrou.liberer()
        messagebox.showerror(APP_NOM, f"Impossible d'ouvrir la base de données :\n{dossier / NOM_FICHIER_DB}"
                                      f"\n\n{e}\n\nJournal : {fichier_journal}")
        root.destroy()
        return 1

    from .ui.app import Application
    try:
        Application(root, theme, base, verrou)
        root.deiconify()
        root.mainloop()
    finally:
        verrou.liberer()
        base.fermer()
        log.info("Fermeture")
    return 0
