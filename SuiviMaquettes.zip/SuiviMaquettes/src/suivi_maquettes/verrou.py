"""Verrou « une seule personne en écriture à la fois » sur le dossier partagé.

Un petit fichier JSON « SuiviMaquettes.verrou » indique qui utilise la base.
La session propriétaire le rafraîchit toutes les 60 s (battement) ; un verrou
sans battement depuis plus de 3 minutes est considéré comme abandonné
(plantage, coupure réseau, PC éteint).

Chaque session détient un jeton unique : si quelqu'un « prend la main »,
l'ancienne session le détecte au battement suivant (ou avant toute écriture)
et repasse automatiquement en lecture seule.
"""

from __future__ import annotations

import getpass
import json
import logging
import os
import socket
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)

NOM_FICHIER = "SuiviMaquettes.verrou"
BATTEMENT_S = 60
PERIME_APRES_S = 180


def utilisateur_courant() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return os.environ.get("USERNAME", "inconnu")


def poste_courant() -> str:
    return os.environ.get("COMPUTERNAME") or socket.gethostname() or "inconnu"


@dataclass(slots=True)
class InfoVerrou:
    jeton: str
    utilisateur: str
    poste: str
    depuis: float
    battement: float

    @property
    def inactif_depuis_s(self) -> float:
        return max(0.0, time.time() - self.battement)

    @property
    def perime(self) -> bool:
        return self.inactif_depuis_s > PERIME_APRES_S


class Verrou:
    def __init__(self, dossier: Path):
        self.chemin = Path(dossier) / NOM_FICHIER
        self.jeton = uuid.uuid4().hex
        self._depuis = time.time()
        self._actif = False
        self._perdu = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------ lecture
    def lire(self) -> InfoVerrou | None:
        try:
            data = json.loads(self.chemin.read_text(encoding="utf-8"))
            return InfoVerrou(
                jeton=str(data["jeton"]), utilisateur=str(data.get("utilisateur", "?")),
                poste=str(data.get("poste", "?")), depuis=float(data.get("depuis", 0)),
                battement=float(data.get("battement", 0)),
            )
        except FileNotFoundError:
            return None
        except (OSError, ValueError, KeyError, TypeError):
            # Fichier illisible ou corrompu : on le considère comme abandonné.
            return InfoVerrou("?", "?", "?", 0.0, 0.0)

    def _contenu(self) -> str:
        return json.dumps({
            "jeton": self.jeton, "utilisateur": utilisateur_courant(), "poste": poste_courant(),
            "pid": os.getpid(), "depuis": self._depuis, "battement": time.time(),
            "info": "Fichier technique de Suivi des maquettes : ne pas modifier.",
        }, ensure_ascii=False, indent=1)

    # ------------------------------------------------------------------ acquisition
    def acquerir(self, forcer: bool = False) -> InfoVerrou | None:
        """Tente de prendre le verrou. Renvoie None si réussi, sinon le verrou en place."""
        if not forcer:
            try:
                fd = os.open(self.chemin, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                autre = self.lire()
                if autre is not None:
                    return autre
                return self.acquerir()          # disparu entre-temps : on réessaie
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(self._contenu())
        else:
            self._ecrire()
        self._actif = True
        self._perdu.clear()
        self._demarrer_battement()
        log.info("Verrou acquis (forcé=%s)", forcer)
        return None

    def _ecrire(self) -> None:
        tmp = self.chemin.with_name(f"{NOM_FICHIER}.{self.jeton[:8]}.tmp")
        tmp.write_text(self._contenu(), encoding="utf-8")
        os.replace(tmp, self.chemin)

    def est_a_nous(self) -> bool:
        if not self._actif:
            return False
        info = self.lire()
        ok = info is not None and info.jeton == self.jeton
        if not ok:
            self._marquer_perdu()
        return ok

    @property
    def perdu(self) -> bool:
        return self._perdu.is_set()

    def _marquer_perdu(self) -> None:
        if self._actif:
            log.warning("Verrou perdu (pris par une autre session)")
        self._actif = False
        self._perdu.set()
        self._stop.set()

    # ------------------------------------------------------------------ battement
    def _demarrer_battement(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(target=self._boucle, name="battement-verrou", daemon=True)
        self._thread.start()

    def _boucle(self) -> None:
        while not self._stop.wait(BATTEMENT_S):
            try:
                if not self.est_a_nous():
                    return
                self._ecrire()
            except OSError as e:          # réseau momentanément indisponible
                log.warning("Battement du verrou impossible : %s", e)

    # ------------------------------------------------------------------ libération
    def liberer(self) -> None:
        self._stop.set()
        if not self._actif:
            return
        try:
            info = self.lire()
            if info is not None and info.jeton == self.jeton:
                self.chemin.unlink(missing_ok=True)
        except OSError as e:
            log.warning("Libération du verrou impossible : %s", e)
        self._actif = False
