"""Export CSV compatible Excel (séparateur « ; », UTF-8 avec BOM)."""

from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path

from .db import Base
from .formats import format_date, format_duree, format_horodatage


def _ecrire(chemin: Path, entetes: list[str], lignes: list[list]) -> None:
    with chemin.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";", quoting=csv.QUOTE_MINIMAL)
        w.writerow(entetes)
        w.writerows(lignes)


def _heures(minutes: int) -> str:
    """Heures décimales à la française (exploitable dans Excel)."""
    return f"{minutes / 60:.2f}".replace(".", ",")


def exporter_tout(base: Base, dossier: Path) -> list[Path]:
    noms = base.noms_parametres()
    suffixe = dt.datetime.now().strftime("%Y-%m-%d_%H%M")
    maquettes = base.liste_maquettes()

    f_maq = dossier / f"maquettes_{suffixe}.csv"
    _ecrire(
        f_maq,
        ["N° de série", "Version config", *noms, "Heures allouées", "Heures consommées",
         "Heures restantes", "Restant (h:mm)", "Nombre de vols", "Dernier vol"],
        [[m.numero_serie, m.version, *m.parametres, _heures(m.alloue), _heures(m.consomme),
          _heures(m.restant), format_duree(m.restant), m.nb_vols, format_date(m.dernier_vol)]
         for m in maquettes],
    )

    f_conf = dossier / f"configurations_{suffixe}.csv"
    lignes = []
    for m in maquettes:
        for c in reversed(base.configurations(m.id)):
            lignes.append([m.numero_serie, c.version, format_date(c.date_effet), c.auteur, c.type,
                           c.demandeur, c.objet, c.commentaire, *c.parametres,
                           format_horodatage(c.saisi_le)])
    _ecrire(f_conf, ["N° de série", "Version", "Date", "Auteur", "Type", "Demandeur", "Objet",
                     "Commentaire", *noms, "Saisi le"], lignes)

    f_vols = dossier / f"vols_{suffixe}.csv"
    lignes = []
    for m in maquettes:
        for v in reversed(base.vols(m.id)):
            lignes.append([m.numero_serie, format_date(v.date_vol), _heures(v.duree),
                           format_duree(v.duree), v.equipe, v.commentaire,
                           format_horodatage(v.saisi_le)])
    _ecrire(f_vols, ["N° de série", "Date du vol", "Durée (h)", "Durée (h:mm)", "Équipe",
                     "Commentaire", "Saisi le"], lignes)

    return [f_maq, f_conf, f_vols]
