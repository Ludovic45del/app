"""Saisie et affichage des durées et des dates (format français).

Les durées sont stockées en MINUTES ENTIÈRES (aucune erreur d'arrondi),
les dates au format ISO « AAAA-MM-JJ » (tri naturel en base).
"""

from __future__ import annotations

import datetime as dt
import re

_RE_HM = re.compile(r"^(\d{1,5})\s*(?:h|:)\s*(\d{1,2})?\s*(?:min|mn|m)?$")
_RE_MIN = re.compile(r"^(\d{1,6})\s*(?:min|mn|m)$")
_RE_DEC = re.compile(r"^(\d{1,5})(?:[.,](\d{1,4}))?\s*h?$")
_RE_DATE_FR = re.compile(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})$")
_RE_DATE_ISO = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")


class ErreurSaisie(ValueError):
    """Valeur saisie invalide ; le message est affichable tel quel."""


def parse_duree(texte: str) -> int:
    """Convertit une saisie libre en minutes.

    Formats acceptés : « 1h30 », « 1:30 », « 1 h », « 90 min », « 1,5 », « 1.5 », « 12 ».
    Un nombre seul est compris comme des heures.
    """
    t = (texte or "").strip().lower().replace(" ", " ")
    if not t:
        raise ErreurSaisie("Durée obligatoire.")
    t = re.sub(r"\s+", " ", t)
    compact = t.replace(" ", "")

    m = _RE_HM.match(compact)
    if m:
        heures, minutes = int(m.group(1)), int(m.group(2) or 0)
        if minutes >= 60:
            raise ErreurSaisie("Les minutes doivent être comprises entre 0 et 59.")
        total = heures * 60 + minutes
    elif (m := _RE_MIN.match(compact)):
        total = int(m.group(1))
    elif (m := _RE_DEC.match(compact)):
        valeur = float(f"{m.group(1)}.{m.group(2) or 0}")
        total = round(valeur * 60)
    else:
        raise ErreurSaisie("Durée non reconnue. Exemples : 1h30, 1:30, 1,5 ou 90 min.")

    if total <= 0:
        raise ErreurSaisie("La durée doit être supérieure à zéro.")
    if total > 99_999 * 60:
        raise ErreurSaisie("Durée trop grande.")
    return total


def format_duree(minutes: int) -> str:
    """1234 -> « 20 h 34 » ; valeurs négatives préfixées par « − »."""
    signe = "−" if minutes < 0 else ""
    h, m = divmod(abs(int(minutes)), 60)
    return f"{signe}{h:,} h {m:02d}".replace(",", " ")


def parse_date(texte: str) -> str:
    """« 26/10/2026 », « 26-10-26 », « 2026-10-26 »… -> « 2026-10-26 »."""
    t = (texte or "").strip()
    if not t:
        raise ErreurSaisie("Date obligatoire.")
    if (m := _RE_DATE_FR.match(t)):
        j, mo, a = int(m.group(1)), int(m.group(2)), m.group(3)
        annee = int(a) + 2000 if len(a) == 2 else int(a)
    elif (m := _RE_DATE_ISO.match(t)):
        annee, mo, j = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        raise ErreurSaisie("Date non reconnue. Format attendu : JJ/MM/AAAA.")
    try:
        d = dt.date(annee, mo, j)
    except ValueError:
        raise ErreurSaisie("Cette date n'existe pas.") from None
    if d.year < 1950:
        raise ErreurSaisie("Date trop ancienne.")
    return d.isoformat()


def format_date(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        return dt.date.fromisoformat(iso[:10]).strftime("%d/%m/%Y")
    except ValueError:
        return iso


def format_horodatage(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        return dt.datetime.fromisoformat(iso).strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return iso


def aujourd_hui_fr() -> str:
    return dt.date.today().strftime("%d/%m/%Y")


def maintenant_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def pourcentage(restant: int, alloue: int) -> float:
    return 0.0 if alloue <= 0 else max(-999.0, restant * 100.0 / alloue)
