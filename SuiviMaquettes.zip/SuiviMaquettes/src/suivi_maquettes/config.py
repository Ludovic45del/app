"""Emplacements et fichier config.ini.

config.ini est cherché, dans l'ordre :
  1. à côté de l'exécutable (ou à la racine du projet en mode développement) ;
  2. dans %APPDATA%\\SuiviMaquettes\\ (si le dossier de l'exe n'est pas modifiable).
"""

from __future__ import annotations

import configparser
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from . import APP_ID

NOM_CONFIG = "config.ini"


def est_compile() -> bool:
    return bool(getattr(sys, "frozen", False))


def dossier_application() -> Path:
    """Dossier contenant l'exe (ou la racine du projet quand on lance depuis les sources)."""
    if est_compile():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def dossier_ressources() -> Path:
    """Dossier des ressources embarquées (icône…)."""
    base = getattr(sys, "_MEIPASS", None)
    return Path(base) if base else dossier_application()


def dossier_utilisateur() -> Path:
    base = os.environ.get("APPDATA") or os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config"
    chemin = Path(base) / APP_ID
    chemin.mkdir(parents=True, exist_ok=True)
    return chemin


def est_exe_unique() -> bool:
    """Exe « fichier unique » : PyInstaller s'extrait dans un dossier temporaire hors du dossier de l'exe."""
    meipass = getattr(sys, "_MEIPASS", None)
    return est_compile() and bool(meipass) and dossier_application() not in Path(meipass).parents


def _candidats_config(ecriture: bool = False) -> list[Path]:
    """Lecture : à côté de l'exe d'abord (permet d'imposer un réglage), puis %APPDATA%.
    Écriture : l'exe unique reste seul (config dans %APPDATA%) ; sinon à côté de l'exe."""
    a_cote, profil = dossier_application() / NOM_CONFIG, dossier_utilisateur() / NOM_CONFIG
    if ecriture and est_exe_unique() and not a_cote.exists():
        return [profil, a_cote]
    return [a_cote, profil]


def lire_dossier_base() -> Path | None:
    for chemin in _candidats_config():
        if chemin.is_file():
            cp = configparser.ConfigParser(interpolation=None)
            try:
                cp.read(chemin, encoding="utf-8-sig")
            except configparser.Error:
                continue
            valeur = cp.get("base", "dossier", fallback="").strip().strip('"')
            if valeur:
                return Path(os.path.expandvars(valeur))
    return None


def ecrire_dossier_base(dossier: Path) -> Path:
    """Enregistre le dossier de la base ; renvoie le fichier config.ini écrit."""
    contenu = (
        "; Configuration de Suivi des maquettes\n"
        "; Dossier (partagé) contenant la base de données suivi_maquettes.db.\n"
        "; Exemples :  dossier = \\\\serveur\\partage\\Maquettes\n"
        ";             dossier = S:\\Association\\Maquettes\n"
        "\n[base]\n"
        f"dossier = {dossier}\n"
    )
    derniere_erreur: OSError | None = None
    for chemin in _candidats_config(ecriture=True):
        try:
            chemin.write_text(contenu, encoding="utf-8")
            return chemin
        except OSError as e:
            derniere_erreur = e
    raise derniere_erreur or OSError("Impossible d'écrire config.ini")


def dossier_accessible(dossier: Path) -> bool:
    try:
        return dossier.is_dir()
    except OSError:
        return False


def dossier_inscriptible(dossier: Path) -> bool:
    test = dossier / f".test_ecriture_{os.getpid()}"
    try:
        test.write_bytes(b"")
        test.unlink()
        return True
    except OSError:
        return False


def configurer_journal() -> Path:
    """Journal technique (erreurs, suppressions…) dans %LOCALAPPDATA%\\SuiviMaquettes."""
    base = os.environ.get("LOCALAPPDATA")
    dossier = Path(base) / APP_ID if base else dossier_utilisateur()
    dossier.mkdir(parents=True, exist_ok=True)
    fichier = dossier / "journal.log"
    handler = RotatingFileHandler(fichier, maxBytes=512_000, backupCount=2, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(name)s : %(message)s"))
    racine = logging.getLogger()
    racine.setLevel(logging.INFO)
    racine.addHandler(handler)
    return fichier
