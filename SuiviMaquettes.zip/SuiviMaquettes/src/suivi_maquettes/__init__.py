"""Suivi des maquettes — gestion des configurations et du potentiel de vol."""

APP_NOM = "Suivi des maquettes"
APP_ID = "SuiviMaquettes"
VERSION = "1.0.0"
NB_PARAMETRES = 9
