@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Suivi des maquettes - Etape 1 : preparation hors ligne
echo.
echo  ================================================================
echo   ETAPE 1 / 2  -  Telechargement des outils de compilation
echo   (une seule fois, connexion internet necessaire)
echo  ================================================================
echo.
call "%~dp0outils\trouver_python.bat" || goto :erreur
echo.
echo  Telechargement des fichiers .whl dans le dossier "wheels"...
%PY% -m pip download --disable-pip-version-check --only-binary=:all: -d wheels -r outils\requirements-build.txt
if errorlevel 1 goto :erreur
echo.
echo  ----------------------------------------------------------------
echo   OK. Le dossier est maintenant autonome : plus besoin d'internet.
echo   Etape suivante : double-cliquez sur 2_COMPILER.bat
echo  ----------------------------------------------------------------
echo.
pause
exit /b 0

:erreur
echo.
echo  ECHEC. Lisez le message ci-dessus et la section "Depannage" du README.
echo.
pause
exit /b 1
