# Suivi des maquettes

Application Windows qui remplace le fichier Excel de suivi des maquettes de l'association :

- **configuration** de chaque maquette (n° de série + 9 paramètres), avec **historique complet** de chaque changement : qui, quand, type, demandeur, objet, commentaire, et quels paramètres ont changé ;
- **potentiel de vol** : heures allouées, décompte automatique à chaque vol (date, durée, équipe responsable, commentaire), alertes visuelles ;
- base de données **partagée** dans un dossier réseau (`\\serveur\partage\...`), **une personne en modification à la fois**, les autres peuvent consulter en lecture seule ;
- **aucune installation** sur les postes : un simple `.exe`, ou un dossier, à copier ;
- **zéro dépendance** pour l'application elle-même : Python standard (Tkinter + SQLite). PyInstaller ne sert qu'à fabriquer l'exe.

---

## Sommaire

1. [Contenu du dossier](#1-contenu-du-dossier)
2. [Prérequis sur votre PC perso (une seule fois)](#2-prérequis-sur-votre-pc-perso-une-seule-fois)
3. [Étape 1 : préparer le dossier hors ligne](#3-étape-1--préparer-le-dossier-hors-ligne)
4. [Étape 2 : compiler](#4-étape-2--compiler)
5. [Étape 3 : transférer sur le PC de travail](#5-étape-3--transférer-sur-le-pc-de-travail)
6. [Étape 4 : mettre en place sur le réseau](#6-étape-4--mettre-en-place-sur-le-réseau)
7. [Premier lancement](#7-premier-lancement)
8. [Utilisation](#8-utilisation)
9. [Travailler à plusieurs](#9-travailler-à-plusieurs)
10. [Sauvegardes et restauration](#10-sauvegardes-et-restauration)
11. [Antivirus d'entreprise](#11-antivirus-dentreprise)
12. [Dépannage](#12-dépannage)
13. [Pour les curieux : fonctionnement technique](#13-pour-les-curieux--fonctionnement-technique)

---

## 1. Contenu du dossier

```
SuiviMaquettes/
├── 1_PREPARER_HORS_LIGNE.bat      ← étape 1 : télécharge les outils (une seule fois, internet)
├── 2_COMPILER.bat                 ← étape 2 : fabrique les exe (hors ligne)
├── 3_CREER_VERSION_PORTABLE.bat   ← plan B si l'antivirus bloque l'exe
├── lancer_depuis_sources.bat      ← lance l'appli sans compiler (pour tester)
├── README.md                      ← ce document
├── src/                           ← code source de l'application
│   ├── main.py
│   └── suivi_maquettes/
├── assets/                        ← icône de l'application
├── tests/                         ← tests automatiques (lancés avant chaque compilation)
├── outils/                        ← scripts de fabrication, modèles de fichiers
├── wheels/                        ← fichiers .whl (remplis à l'étape 1)
└── livraison/                     ← CRÉÉ à l'étape 2 : ce que vous transférez
```

Après compilation, le dossier `livraison/` contient :

| Élément | Description | Quand l'utiliser |
|---|---|---|
| `SuiviMaquettes/` | Version **dossier** : `SuiviMaquettes.exe` + un sous-dossier `_internal` | **Recommandée en entreprise** : démarre instantanément et passe mieux les antivirus |
| `SuiviMaquettes.exe` | Version **fichier unique** : tout est dans l'exe | Pratique à copier, mais démarre en 1 à 3 s et est plus souvent bloquée par les antivirus |
| `EMPREINTES_SHA256.txt` | Empreintes des deux exe | À donner au service informatique pour une exception antivirus |

> **La base de données n'est pas dans l'exe**, et c'est voulu : elle doit être partagée et modifiée par tous. Elle vit dans le dossier réseau (fichier `suivi_maquettes.db`), créée automatiquement au premier lancement.

---

## 2. Prérequis sur votre PC perso (une seule fois)

Vous avez déjà Python 3.13. Vérifiez seulement deux points :

1. **Python vient de python.org** (pas du Microsoft Store). Pour le savoir, ouvrez un terminal (touche Windows, tapez `cmd`, Entrée) et tapez :
   ```
   py -3.13 -c "import sys; print(sys.executable)"
   ```
   Si le chemin contient `WindowsApps`, c'est la version du Store : installez plutôt Python 3.13 depuis <https://www.python.org/downloads/windows/> (« Windows installer (64-bit) »).

2. **Tkinter est installé.** Dans le même terminal :
   ```
   py -3.13 -c "import tkinter; print('Tkinter OK')"
   ```
   En cas d'erreur, relancez l'installeur Python, choisissez **Modify** et cochez **tcl/tk and IDLE**.

> Si vous installez Python, cochez **« Add python.exe to PATH »** sur le premier écran de l'installeur.

**Le PC de travail n'a besoin de rien** : ni Python, ni droits administrateur, ni internet.

---

## 3. Étape 1 : préparer le dossier hors ligne

*Sur votre PC perso, avec internet, une seule fois.*

Double-cliquez sur **`1_PREPARER_HORS_LIGNE.bat`**.

Il télécharge PyInstaller et ses dépendances sous forme de fichiers `.whl` dans le dossier `wheels/` (quelques Mo). Ensuite, **le dossier est autonome** : vous pouvez le copier sur une clé USB et recompiler sur n'importe quel PC Windows équipé de Python, sans internet.

---

## 4. Étape 2 : compiler

*Sur votre PC perso, internet non nécessaire.*

Double-cliquez sur **`2_COMPILER.bat`**. Il enchaîne automatiquement :

1. la création d'un environnement Python isolé (`.venv-build/`) : **votre installation Python n'est pas modifiée** ;
2. l'installation de PyInstaller **depuis le dossier `wheels/`**, sans internet ;
3. les **tests automatiques** de l'application. Si l'un échoue, la compilation est annulée ;
4. la fabrication des deux versions, puis l'ouverture du dossier `livraison/`.

Durée : 1 à 3 minutes. Taille obtenue : environ 10 à 25 Mo selon la version.

**Avant de transférer**, vous pouvez essayer l'application sur votre PC :
- ouvrez un terminal dans le dossier et créez une base de démonstration :
  ```
  py -3.13 outils\donnees_demo.py C:\Temp\DemoMaquettes
  ```
- lancez `livraison\SuiviMaquettes\SuiviMaquettes.exe` et indiquez `C:\Temp\DemoMaquettes` comme dossier.

---

## 5. Étape 3 : transférer sur le PC de travail

Copiez sur la clé USB **le contenu de `livraison/`**. Vous n'avez besoin que d'une des deux versions, mais prenez les deux pour pouvoir tester.

Sur le PC de travail, copiez **dans un dossier de votre profil**, par exemple `C:\Users\<vous>\Applications\SuiviMaquettes\` :
- soit le dossier `SuiviMaquettes\` complet, **sans le séparer de son sous-dossier `_internal`** ;
- soit le fichier `SuiviMaquettes.exe` seul.

> **Ne lancez pas l'exe directement depuis le partage réseau ni depuis la clé USB** : beaucoup d'antivirus d'entreprise bloquent les programmes lancés depuis un lecteur réseau ou amovible. L'exe va sur chaque poste, seule la base va sur le partage.

Si Windows affiche « Windows a protégé votre ordinateur » (SmartScreen) : cliquez sur **Informations complémentaires**, puis **Exécuter quand même**. Ce message n'apparaît qu'une fois. Si l'exe est bloqué ou supprimé, voir la [section 11](#11-antivirus-dentreprise).

Astuce : clic droit sur `SuiviMaquettes.exe` > **Afficher d'autres options** > **Envoyer vers** > **Bureau (créer un raccourci)**.

---

## 6. Étape 4 : mettre en place sur le réseau

1. Sur le partage, créez un dossier dédié, par exemple `\\serveur\partage\Maquettes`.
2. Vérifiez que **tous les utilisateurs ont les droits de lecture et d'écriture** sur ce dossier. L'application y écrit la base, un fichier de verrou et les sauvegardes.
3. C'est tout. La base est créée au premier lancement.

Contenu du dossier partagé une fois en service :

```
\\serveur\partage\Maquettes\
├── suivi_maquettes.db           ← LA base de données (tout est dedans)
├── SuiviMaquettes.verrou        ← présent seulement quand quelqu'un modifie (ne pas toucher)
└── sauvegardes\                 ← copies automatiques (les 60 dernières)
```

**Pour les autres utilisateurs :** donnez-leur l'exe (ou le dossier) et le chemin `\\serveur\partage\Maquettes`. Pour leur éviter de saisir le chemin, copiez `config.ini.exemple` à côté de leur exe, renommez-le `config.ini` et mettez le bon chemin à la ligne `dossier =`.

---

## 7. Premier lancement

1. Double-cliquez sur `SuiviMaquettes.exe`.
2. L'application demande le **dossier de la base** : collez `\\serveur\partage\Maquettes` (copié depuis la barre d'adresse de l'Explorateur) ou cliquez sur **Parcourir…**.
3. Si aucune base n'existe encore, elle propose d'en créer une : répondez **Oui** (une seule personne le fait, la première fois).
4. Ouvrez **Réglages** et donnez leurs vrais noms aux **9 paramètres** (par défaut « Paramètre 1 » à « Paramètre 9 »), et éventuellement le nom de l'association. Ces réglages sont stockés dans la base : tout le monde les voit.

Le chemin choisi est mémorisé :
- version dossier : dans `config.ini`, à côté de l'exe ;
- version exe unique : dans `%APPDATA%\SuiviMaquettes\config.ini`, pour que l'exe reste seul.

---

## 8. Utilisation

### Écran principal

- **À gauche**, la liste des maquettes : pastille de couleur, n° de série, version de configuration, temps restant, pourcentage et date du dernier vol. Cliquez sur un en-tête de colonne pour **trier**.
- **À droite**, la fiche de la maquette sélectionnée : heures allouées, consommées et restantes, barre de potentiel, puis trois onglets :
  - **Configuration actuelle** : les 9 paramètres ;
  - **Historique** : toutes les versions. En cliquant sur une version, vous voyez ses paramètres ; ceux qui ont changé sont marqués « ● modifié », avec l'ancienne valeur ;
  - **Carnet de vols** : tous les vols, le plus récent en haut.

Code couleur : 🟢 au-dessus du seuil d'alerte · 🟠 sous le seuil (20 % par défaut, réglable) · 🔴 potentiel épuisé ou dépassé.

### Actions

| Action | Comment | Règles |
|---|---|---|
| **Nouvelle maquette** | Bouton bleu en haut de la liste, ou `Ctrl+N` | N° de série unique (sans distinction majuscules/minuscules), heures allouées > 0, auteur obligatoire. Les heures allouées sont **définitives** (non modifiables). |
| **Nouvelle configuration** | Bouton sur la fiche | Au moins un paramètre doit changer. Auteur, date, type, demandeur et objet sont obligatoires ; le commentaire est facultatif. Les champs modifiés s'affichent en bleu avec l'ancienne valeur. |
| **Enregistrer un vol** | Bouton bleu sur la fiche | Date, durée et équipe sont obligatoires. Un aperçu montre le temps restant après le vol. Si le vol dépasse le potentiel, un avertissement demande confirmation. |
| **Supprimer un vol** | Onglet *Carnet de vols* > sélectionner > **Supprimer ce vol** (ou touche `Suppr`) | Cocher « Je confirme… », puis valider. Le temps du vol est recrédité. |
| **Supprimer une maquette** | Bouton **Supprimer** sur la fiche | Il faut **retaper le n° de série**. La maquette, ses configurations et ses vols sont supprimés. |
| **Rechercher** | Champ au-dessus de la liste, ou `Ctrl+F` | Cherche dans le n° de série et dans les 9 paramètres. `Échap` efface. |
| **Exporter** | Bouton **Exporter (CSV)**, ou `Ctrl+E` | Crée 3 fichiers qui s'ouvrent directement dans Excel : maquettes, historique des configurations, vols. |
| **Actualiser** | Bouton ou `F5` | Utile en lecture seule pour voir les saisies de la personne qui modifie. |

**Saisie des durées** : `1h30`, `1:30`, `1,5`, `1.5`, `90 min`, `2h` ou `12` (= 12 heures). Les durées sont stockées **à la minute près**, sans erreur d'arrondi.

**Saisie des dates** : `26/10/2026`, `26/10/26`, `26-10-2026`. Le jour même est prérempli.

**Clavier** : `Entrée` valide une fenêtre (sauf les suppressions, qui demandent un clic), `Échap` l'annule, `Tab` passe au champ suivant.

### Gardes-fous des suppressions

1. confirmation explicite : retaper le n° de série, ou cocher une case pour un vol ;
2. bouton « Supprimer » désactivé tant que la confirmation n'est pas faite, et la touche Entrée ne déclenche jamais une suppression ;
3. **sauvegarde complète automatique de la base juste avant** chaque suppression ;
4. trace dans le journal technique du poste (date, heure, élément supprimé).

---

## 9. Travailler à plusieurs

Une seule personne peut **modifier** à la fois : c'est ce qui garantit qu'aucune saisie n'est écrasée sur un partage réseau. Au lancement, si quelqu'un modifie déjà, une fenêtre indique **qui, sur quel poste, depuis quand**, et propose :

- **Ouvrir en lecture seule** (par défaut) : tout est consultable et exportable, rien n'est modifiable. Un bandeau jaune « LECTURE SEULE » s'affiche. `F5` recharge les données ;
- **Prendre la main** : vous passez en modification. L'autre session le détecte en quelques secondes, **passe automatiquement en lecture seule** et prévient son utilisateur. Rien de ce qu'il avait enregistré n'est perdu, car chaque saisie est enregistrée immédiatement ;
- **Quitter**.

Si l'application a été fermée brutalement (plantage, coupure réseau, PC éteint), la fenêtre l'indique (« aucune activité depuis… ») et vous pouvez prendre la main sans risque.

> **Bonne pratique : fermez l'application quand vous avez fini**, pour libérer la modification pour les autres.

---

## 10. Sauvegardes et restauration

Les sauvegardes sont **automatiques**, dans `\\serveur\partage\Maquettes\sauvegardes\` :

| Quand | Nom du fichier |
|---|---|
| Une fois par jour, au premier lancement en modification | `suivi_maquettes_AAAA-MM-JJ_HHMMSS_quotidienne.db` |
| Avant chaque suppression | `…_avant-suppression-vol.db` / `…_avant-suppression-maquette.db` |
| Avant une restauration | `…_avant-restauration.db` |
| À la demande (Réglages > Sauvegarder maintenant) | `…_manuelle.db` |

Les **60 plus récentes** sont conservées. Les sauvegardes utilisent l'API officielle de SQLite : elles sont toujours cohérentes, même en cas d'écriture simultanée.

**Restaurer** : **Réglages** > **Restaurer une sauvegarde…**, puis choisissez le fichier. L'état actuel est lui-même sauvegardé avant d'être remplacé : une restauration se défait toujours.

**Recommandé** : demandez que le dossier partagé soit inclus dans la sauvegarde du serveur, ou copiez de temps en temps `suivi_maquettes.db` ailleurs.

---

## 11. Antivirus d'entreprise

Les exe produits par PyInstaller ne sont pas signés numériquement, et certains antivirus les bloquent par précaution. Ce n'est pas lié au contenu de l'application. Plusieurs précautions sont déjà prises : pas de compression UPX (souvent signalée), informations de version intégrées à l'exe, aucun accès réseau ni internet, aucune écriture hors du dossier partagé et de votre profil.

Si l'exe est bloqué, procédez dans l'ordre :

1. **Essayez la version dossier** (`SuiviMaquettes\SuiviMaquettes.exe`), copiée dans votre profil (`C:\Users\<vous>\...`), et non sur le réseau ni sur la clé USB.
2. **Demandez une exception au service informatique**, en leur transmettant `EMPREINTES_SHA256.txt`. L'empreinte identifie exactement votre exe.
3. **Plan B : la version portable sans exe compilé.** Sur votre PC perso, double-cliquez sur `3_CREER_VERSION_PORTABLE.bat`. Il crée `livraison\SuiviMaquettes_portable\`, qui contient :
   - une copie de **Python officiel** : `python.exe` et `pythonw.exe` sont **signés par la Python Software Foundation**, donc rarement bloqués ;
   - le code source de l'application ;
   - `Suivi des maquettes.bat` pour la lancer.

   Copiez ce dossier entier (environ 40 à 60 Mo) sur le PC de travail et lancez `Suivi des maquettes.bat`. Une fenêtre noire apparaît une fraction de seconde, c'est normal. Les données et le fonctionnement sont identiques.

---

## 12. Dépannage

| Problème | Solution |
|---|---|
| `1_PREPARER_HORS_LIGNE.bat` : « Python introuvable » | Installez Python depuis python.org en cochant « Add python.exe to PATH » (voir [section 2](#2-prérequis-sur-votre-pc-perso-une-seule-fois)). |
| `1_PREPARER…` : erreur réseau ou SSL | Vérifiez internet. Sur un réseau d'entreprise avec proxy, faites cette étape depuis votre réseau personnel. |
| `2_COMPILER.bat` : « Le dossier wheels est vide » | Lancez d'abord `1_PREPARER_HORS_LIGNE.bat`. |
| `2_COMPILER.bat` : « Des tests ont échoué » | Le code a été modifié et contient une erreur : le détail s'affiche. Corrigez, ou revenez à la version d'origine. |
| Compilation : erreur après une mise à jour de Python | Supprimez le dossier `.venv-build` et relancez `2_COMPILER.bat`. |
| Au lancement : « Le dossier configuré est inaccessible » | Réseau ou VPN déconnecté, ou droits manquants. Vérifiez que le dossier s'ouvre dans l'Explorateur, puis cliquez sur **Continuer**. |
| « Vous n'avez pas les droits d'écriture » | Demandez les droits de modification sur le dossier partagé. En attendant, la lecture seule est possible. |
| L'application dit que la base est utilisée, alors que personne ne l'a ouverte | Session interrompue : choisissez **Prendre la main**. |
| « Créée par une version plus récente de l'application » | Un collègue utilise une version plus récente : utilisez le même exe que lui. |
| L'affichage est flou | Clic droit sur l'exe > Propriétés > Compatibilité > *Modifier les paramètres PPP élevés* > décochez tout. L'application gère normalement elle-même la haute résolution. |
| Erreur inattendue | Le détail se trouve dans `%LOCALAPPDATA%\SuiviMaquettes\journal.log` (collez ce chemin dans la barre d'adresse de l'Explorateur). |

---

## 13. Pour les curieux : fonctionnement technique

### Architecture

```
src/
├── main.py                       point d'entrée
└── suivi_maquettes/
    ├── __init__.py               nom, version, nombre de paramètres (9)
    ├── demarrage.py              séquence de lancement : dossier, verrou, ouverture
    ├── config.py                 config.ini, emplacements, journal
    ├── db.py                     base SQLite : schéma, lectures, écritures, sauvegardes
    ├── verrou.py                 « une seule personne en modification à la fois »
    ├── formats.py                saisie et affichage des durées et des dates
    ├── export.py                 export CSV pour Excel
    └── ui/
        ├── theme.py              palette, polices, styles
        ├── widgets.py            tableau triable, onglets, barre de potentiel, recherche
        ├── dialogs.py            toutes les fenêtres de saisie et de confirmation
        └── app.py                fenêtre principale
```

### Choix techniques

- **Tkinter + ttk (thème « clam » entièrement restylé)** : inclus dans Python, aucun moteur web, démarrage instantané. Les images (pastilles, barre de potentiel) sont générées à la volée en PNG lissé, nettes à toutes les échelles d'affichage. L'application déclare la gestion « haute résolution » à Windows 11, ce qui donne un texte net à 125 % et 150 %.
- **SQLite** : un seul fichier, transactions atomiques (une saisie est entièrement enregistrée ou pas du tout), contraintes d'intégrité (n° de série unique, durées > 0, suppression en cascade). Réglages adaptés au partage réseau : journal `DELETE` (le mode WAL est incompatible avec les partages SMB) et écriture synchrone complète. En lecture seule, la connexion est verrouillée au niveau de SQLite (`query_only`).
- **Verrou applicatif** : fichier JSON avec un jeton unique par session, rafraîchi toutes les 60 s par un fil d'exécution de fond, pour ne jamais figer l'interface. Il est considéré comme abandonné après 3 minutes sans activité, et vérifié avant chaque écriture.
- **Performance** : la liste complète est obtenue en **une seule requête SQL** (agrégats calculés par la base, index sur les vols). Les rafraîchissements de l'interface sont regroupés pour éviter les requêtes en double sur le réseau. La recherche et le tri se font en mémoire, instantanément.
- **Durées en minutes entières** : aucune erreur d'arrondi, même après des centaines de vols.

### Schéma de la base

| Table | Colonnes principales |
|---|---|
| `maquette` | `id`, `numero_serie` (unique), `heures_allouees_min`, `cree_le` |
| `configuration` | `maquette_id`, `version`, `p1`…`p9`, `date_effet`, `auteur`, `type`, `demandeur`, `objet`, `commentaire`, `saisi_le` |
| `vol` | `maquette_id`, `date_vol`, `duree_min`, `equipe`, `commentaire`, `saisi_le` |
| `reglage` | `cle`, `valeur` (noms des paramètres, seuil d'alerte, nom de l'association) |

La base peut être ouverte avec [DB Browser for SQLite](https://sqlitebrowser.org/) pour consultation. Ne la modifiez pas pendant que l'application est ouverte.

### Modifier l'application

1. Modifiez le code dans `src/`.
2. Testez sans compiler : `lancer_depuis_sources.bat`.
3. Lancez les tests : `py -3.13 tests\test_donnees.py`.
4. Augmentez `VERSION` dans `src/suivi_maquettes/__init__.py`.
5. Recompilez avec `2_COMPILER.bat` (hors ligne), puis redistribuez l'exe.

Le schéma de la base est versionné (`PRAGMA user_version`) : une future version saura faire évoluer une base existante sans perte de données.

### Changer l'icône

Remplacez les fichiers de `assets/`, ou modifiez `outils/generer_icone.py` puis lancez-le (il nécessite `pip install pillow`, uniquement pour cet outil).
