"""Génère assets/app.ico et assets/logo_*.png (nécessite Pillow ; déjà fait, à relancer seulement
si vous voulez changer l'icône :  python outils/generer_icone.py)."""

from pathlib import Path

from PIL import Image, ImageDraw

RACINE = Path(__file__).resolve().parents[1]
ASSETS = RACINE / "assets"
N = 1024


def dessiner() -> Image.Image:
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    # Fond : carré arrondi en dégradé bleu nuit -> bleu
    fond = Image.new("RGBA", (N, N))
    d = ImageDraw.Draw(fond)
    haut, bas = (0x1F, 0x5B, 0xB4), (0x13, 0x21, 0x3B)
    for y in range(N):
        t = y / (N - 1)
        d.line([(0, y), (N, y)], fill=tuple(int(haut[i] + (bas[i] - haut[i]) * t) for i in range(3)))
    masque = Image.new("L", (N, N), 0)
    ImageDraw.Draw(masque).rounded_rectangle([0, 0, N - 1, N - 1], radius=int(N * 0.22), fill=255)
    img.paste(fond, (0, 0), masque)

    # Avion vu de dessus
    droite = [(0.5, 0.08), (0.538, 0.15), (0.548, 0.40), (0.88, 0.57), (0.88, 0.635), (0.548, 0.55),
              (0.542, 0.75), (0.68, 0.84), (0.68, 0.885), (0.53, 0.855), (0.5, 0.9)]
    gauche = [(1 - x, y) for x, y in reversed(droite[1:-1])]
    avion = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    echelle, decal = 0.74, (1 - 0.74) / 2
    pts = [((decal + x * echelle) * N, (decal + y * echelle) * N) for x, y in droite + gauche]
    ImageDraw.Draw(avion).polygon(pts, fill=(255, 255, 255, 255))
    avion = avion.rotate(-45, resample=Image.BICUBIC, center=(N / 2, N / 2))
    img.alpha_composite(avion)
    return img


def main() -> None:
    ASSETS.mkdir(exist_ok=True)
    img = dessiner()
    img.save(ASSETS / "app.ico", sizes=[(s, s) for s in (16, 20, 24, 32, 40, 48, 64, 128, 256)])
    for s in (24, 32, 40, 48, 256):
        img.resize((s, s), Image.LANCZOS).save(ASSETS / f"logo_{s}.png")
    print("Icônes générées dans", ASSETS)


if __name__ == "__main__":
    main()
