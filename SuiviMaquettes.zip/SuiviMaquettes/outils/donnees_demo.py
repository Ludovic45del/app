"""Crée une base de démonstration pour essayer l'application sans toucher aux vraies données.

    python outils\\donnees_demo.py  C:\\Temp\\DemoMaquettes

Puis lancez l'application et choisissez ce dossier.
"""

import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from suivi_maquettes.db import NOM_FICHIER_DB, Base, Trace  # noqa: E402


def main() -> None:
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
    dossier = Path(sys.argv[1])
    dossier.mkdir(parents=True, exist_ok=True)
    if (dossier / NOM_FICHIER_DB).exists():
        sys.exit(f"Une base existe déjà dans {dossier} : rien n'a été modifié.")
    rnd = random.Random(7)
    base = Base(dossier)
    base.definir_reglages({"nom_asso": "Association de modélisme — démonstration",
                           "nom_p1": "Moteur", "nom_p2": "Hélice", "nom_p3": "Batterie",
                           "nom_p4": "Récepteur", "nom_p5": "Servos", "nom_p6": "Train",
                           "nom_p7": "Aile", "nom_p8": "Empennage", "nom_p9": "Centrage"})
    equipes = ["Équipe Alpha", "Équipe Bravo", "Équipe Charlie", "Jeunes pilotes"]
    personnes = ["M. Durand", "S. Martin", "L. Bernard", "C. Petit", "A. Moreau"]
    for i in range(1, 21):
        params = [f"Moteur {rnd.choice(['A', 'B', 'C'])}{rnd.randint(10, 60)}",
                  f"{rnd.randint(9, 14)}x{rnd.randint(4, 8)}", f"LiPo {rnd.choice([3, 4, 6])}S",
                  rnd.choice(["R-8 v2", "R-12", "R-6 mini"]), f"{rnd.randint(4, 8)} × MG90",
                  rnd.choice(["Tricycle", "Classique", "Sans train"]),
                  rnd.choice(["Profil plat", "Clark Y", "NACA 2412"]),
                  rnd.choice(["En T", "Classique", "En V"]), f"{rnd.randint(28, 38)} % CMA"]
        alloue = rnd.choice([30, 40, 50, 60]) * 60
        mid = base.creer_maquette(f"MQ-{2024 + i // 8}-{i:03d}", alloue, params,
                                  Trace(auteur=rnd.choice(personnes), date_effet="2025-03-01",
                                        type="Configuration initiale", objet="Mise en service"))
        for v in range(rnd.randint(0, 3)):
            idx = rnd.randrange(9)
            params = list(params)
            params[idx] = params[idx] + " (mod.)"
            base.nouvelle_configuration(mid, params, Trace(
                auteur=rnd.choice(personnes), date_effet=f"2025-{5 + v * 2:02d}-1{v}",
                type=rnd.choice(["Évolution", "Réparation", "Maintenance"]),
                demandeur=rnd.choice(personnes), objet=rnd.choice(
                    ["Amélioration des performances", "Casse à l'atterrissage", "Révision annuelle"]),
                commentaire="Essais au sol concluants."))
        cible = alloue * rnd.uniform(0.2, 1.05)
        total = 0
        while total < cible:
            d = rnd.choice([15, 20, 30, 45, 60, 90])
            total += d
            base.ajouter_vol(mid, f"2025-{rnd.randint(4, 12):02d}-{rnd.randint(1, 28):02d}", d,
                             rnd.choice(equipes), rnd.choice(["", "RAS", "Vent fort, vol écourté",
                                                              "Atterrissage dur, à vérifier"]))
    base.fermer()
    print(f"Base de démonstration créée dans {dossier}")


if __name__ == "__main__":
    main()
