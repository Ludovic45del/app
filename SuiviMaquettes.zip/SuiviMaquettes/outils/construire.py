"""Fabrique les livrables Windows dans le dossier « livraison ».

    python outils\\construire.py             -> version dossier + exe unique (PyInstaller)
    python outils\\construire.py --portable  -> plan B : version portable sans exe compilé

Appelé par 2_COMPILER.bat et 3_CREER_VERSION_PORTABLE.bat : vous n'avez normalement
pas besoin de le lancer à la main.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
SRC = RACINE / "src"
ASSETS = RACINE / "assets"
LIVRAISON = RACINE / "livraison"
TRAVAIL = RACINE / "build"
NOM = "SuiviMaquettes"

sys.path.insert(0, str(SRC))
from suivi_maquettes import VERSION  # noqa: E402

# Modules de la bibliothèque standard inutiles à l'application : exe plus léger.
EXCLUSIONS = ["unittest", "pydoc", "doctest", "pdb", "test", "lib2to3", "xmlrpc",
              "setuptools", "pkg_resources", "distutils", "ensurepip", "idlelib", "turtledemo"]


def titre(texte: str) -> None:
    print(f"\n=== {texte} ===", flush=True)


def fichier_version() -> Path:
    v = tuple(int(x) for x in VERSION.split(".")) + (0,)
    contenu = f"""# Informations de version intégrées à l'exe (Propriétés > Détails dans Windows)
VSVersionInfo(
  ffi=FixedFileInfo(filevers={v}, prodvers={v}, mask=0x3f, flags=0x0, OS=0x40004,
                    fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040C04B0', [
      StringStruct('CompanyName', 'Association de modélisme'),
      StringStruct('FileDescription', 'Suivi des maquettes'),
      StringStruct('FileVersion', '{VERSION}'),
      StringStruct('InternalName', '{NOM}'),
      StringStruct('LegalCopyright', 'Usage interne à l association'),
      StringStruct('OriginalFilename', '{NOM}.exe'),
      StringStruct('ProductName', 'Suivi des maquettes'),
      StringStruct('ProductVersion', '{VERSION}')])]),
    VarFileInfo([VarStruct('Translation', [0x040C, 1200])])
  ]
)
"""
    TRAVAIL.mkdir(exist_ok=True)
    chemin = TRAVAIL / "version_info.txt"
    chemin.write_text(contenu, encoding="utf-8")
    return chemin


def pyinstaller(mode: str) -> Path:
    import PyInstaller.__main__

    dist = TRAVAIL / f"dist-{mode}"
    args = [
        str(SRC / "main.py"), "--name", NOM, "--noconfirm", "--clean", "--windowed",
        "--icon", str(ASSETS / "app.ico"),
        "--add-data", f"{ASSETS}{os.pathsep}assets",
        "--version-file", str(fichier_version()),
        "--paths", str(SRC), "--noupx",
        "--distpath", str(dist), "--workpath", str(TRAVAIL / f"work-{mode}"),
        "--specpath", str(TRAVAIL),
        "--log-level", "WARN",
    ]
    for m in EXCLUSIONS:
        args += ["--exclude-module", m]
    args.append("--onefile" if mode == "exe-unique" else "--onedir")
    PyInstaller.__main__.run(args)
    return dist


def empreinte(f: Path) -> str:
    h = hashlib.sha256()
    with f.open("rb") as fh:
        for bloc in iter(lambda: fh.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest().upper()


def taille(chemin: Path) -> str:
    total = chemin.stat().st_size if chemin.is_file() else sum(
        f.stat().st_size for f in chemin.rglob("*") if f.is_file())
    return f"{total / 1_048_576:.1f} Mo"


def copier_documents(cible: Path) -> None:
    shutil.copy2(RACINE / "outils" / "config.ini.exemple", cible / "config.ini.exemple")
    shutil.copy2(RACINE / "outils" / "LISEZMOI_UTILISATEURS.txt", cible / "LISEZMOI.txt")


def construire_exe() -> None:
    LIVRAISON.mkdir(exist_ok=True)

    titre("1/2  Version DOSSIER (recommandée en entreprise)")
    dist = pyinstaller("dossier")
    cible_dossier = LIVRAISON / NOM
    shutil.rmtree(cible_dossier, ignore_errors=True)
    shutil.copytree(dist / NOM, cible_dossier)
    copier_documents(cible_dossier)

    titre("2/2  Version EXE UNIQUE")
    dist = pyinstaller("exe-unique")
    cible_exe = LIVRAISON / f"{NOM}.exe"
    cible_exe.unlink(missing_ok=True)
    shutil.copy2(dist / f"{NOM}.exe", cible_exe)

    lignes = [f"Suivi des maquettes {VERSION} - empreintes SHA-256 (à transmettre au service "
              "informatique si l'antivirus demande une exception)", ""]
    for f in (cible_dossier / f"{NOM}.exe", cible_exe):
        lignes.append(f"{f.relative_to(LIVRAISON)}\n  {empreinte(f)}")
    (LIVRAISON / "EMPREINTES_SHA256.txt").write_text("\n".join(lignes) + "\n", encoding="utf-8")

    titre("Terminé")
    print(f"  {cible_dossier}   ({taille(cible_dossier)})")
    print(f"  {cible_exe}   ({taille(cible_exe)})")


def construire_portable() -> None:
    """Plan B antivirus : Python officiel (exécutables signés par la Python Software Foundation)
    copié à côté du code source. Aucun exe « fait maison » : rarement bloqué."""
    base = Path(sys.base_prefix)
    if sys.platform != "win32":
        sys.exit("La version portable se fabrique sous Windows.")
    if "WindowsApps" in str(base):
        sys.exit("Python du Microsoft Store détecté : installez Python depuis python.org "
                 "(voir README) pour fabriquer la version portable.")

    cible = LIVRAISON / f"{NOM}_portable"
    titre(f"Version PORTABLE depuis {base}")
    shutil.rmtree(cible, ignore_errors=True)
    runtime = cible / "runtime"
    runtime.mkdir(parents=True)

    for motif in ("python.exe", "pythonw.exe", "python3*.dll", "vcruntime*.dll", "LICENSE.txt"):
        for f in base.glob(motif):
            shutil.copy2(f, runtime / f.name)
    shutil.copytree(base / "DLLs", runtime / "DLLs")
    if (base / "tcl").exists():
        shutil.copytree(base / "tcl", runtime / "tcl")
    ignorer = shutil.ignore_patterns("__pycache__", "site-packages", "test", "tests", "idlelib",
                                     "ensurepip", "lib2to3", "turtledemo", "venv", "*.pyc")
    shutil.copytree(base / "Lib", runtime / "Lib", ignore=ignorer)
    (runtime / "Lib" / "site-packages").mkdir()

    shutil.copytree(SRC, cible / "app", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(ASSETS, cible / "assets")
    copier_documents(cible)
    (cible / "Suivi des maquettes.bat").write_text(
        '@echo off\r\nstart "" "%~dp0runtime\\pythonw.exe" -I "%~dp0app\\main.py"\r\n', encoding="ascii")

    titre("Terminé")
    print(f"  {cible}   ({taille(cible)})")
    print("  Lancez « Suivi des maquettes.bat » (ou créez-en un raccourci sur le bureau).")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--portable", action="store_true")
    if p.parse_args().portable:
        construire_portable()
    else:
        construire_exe()
