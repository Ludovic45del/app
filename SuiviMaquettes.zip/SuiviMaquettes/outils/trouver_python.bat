@echo off
rem Cherche Python (3.13 de preference) et le met dans la variable PY. Appele par les autres .bat.
set "PY="
py -3.13 -c "import sys" >nul 2>&1 && set "PY=py -3.13"
if not defined PY py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1 && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1 && set "PY=python"
if not defined PY (
    echo.
    echo  [ERREUR] Python introuvable.
    echo  Installez Python 3.13 depuis https://www.python.org/downloads/windows/
    echo  en cochant "Add python.exe to PATH" ^(voir README, etape 0^).
    exit /b 1
)
%PY% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERREUR] Python est installe sans Tkinter.
    echo  Relancez l'installeur Python, choisissez "Modify" et cochez "tcl/tk and IDLE".
    exit /b 1
)
for /f "delims=" %%v in ('%PY% --version') do echo  Python utilise : %%v  ^(%PY%^)
exit /b 0
